"use strict";

const contracts = [
  {
    name: "RepositoryConfig",
    run: require("./repository-config.contract.cjs")
  },
  {
    name: "WorkspaceConfig",
    run: require("./workspace-config.contract.cjs")
  },
  {
    name: "AuthorizationRequest",
    run: require("./authorization-request.contract.cjs")
  },
  {
    name: "AuthorizationDecision",
    run: require("./authorization-decision.contract.cjs")
  }
];

let failures = 0;
let countedCases = 0;

for (const contract of contracts) {
  try {
    const result = contract.run();
    if (Number.isInteger(result) && result > 0) {
      countedCases += result;
      console.log(`PASS ${contract.name} (${result} cases)`);
    } else {
      console.log(`PASS ${contract.name}`);
    }
  } catch (error) {
    failures += 1;
    console.error(`FAIL ${contract.name}: ${error.message}`);
  }
}

if (failures > 0) {
  console.error(`${failures} contract suite(s) failed.`);
  process.exitCode = 1;
} else {
  console.log(
    `${contracts.length} contract suite(s) passed; ${countedCases} explicitly counted authorization cases.`
  );
}
