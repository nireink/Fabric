"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const {
  DECISION_ALLOWED_PROPERTIES,
  createFailClosedDecision,
  validateAuthorizationDecision
} = require("../../tools/validate-authorization.cjs");

const PROJECT_ROOT = path.resolve(__dirname, "..", "..");

function validRequest(overrides = {}) {
  return {
    requestId: "request-001",
    operation: "write",
    requestedPermissions: ["read", "write"],
    ...overrides
  };
}

function grantedDecision(overrides = {}) {
  return {
    requestId: "request-001",
    decisionId: "decision-001",
    decision: "granted",
    allowed: true,
    requiresHumanApproval: false,
    grantedPermissions: ["read", "write"],
    deniedPermissions: [],
    reason: "Authorized by a valid future GDA policy.",
    decidedBy: "GDA",
    decidedAt: "2026-07-24T12:00:00.000Z",
    auditReference: "audit-001",
    expiresAt: "2999-07-24T13:00:00.000Z",
    ...overrides
  };
}

function requiresHumanDecision(overrides = {}) {
  return {
    requestId: "request-001",
    decisionId: "decision-002",
    decision: "requires-human-approval",
    allowed: false,
    requiresHumanApproval: true,
    grantedPermissions: [],
    deniedPermissions: ["write"],
    reason: "Human approval is required.",
    decidedBy: "Human",
    decidedAt: "2026-07-24T12:00:00.000Z",
    auditReference: "audit-002",
    ...overrides
  };
}

function expectError(value, request, expectedText) {
  const errors = validateAuthorizationDecision(value, request);
  assert.ok(
    errors.some((error) => error.includes(expectedText)),
    `Expected error containing "${expectedText}", received: ${errors.join(" | ")}`
  );
}

function runAuthorizationDecisionContracts() {
  const request = validRequest();

  const schema = JSON.parse(
    fs.readFileSync(
      path.join(
        PROJECT_ROOT,
        "schemas",
        "authorization-decision.schema.json"
      ),
      "utf8"
    )
  );
  assert.strictEqual(schema.additionalProperties, false);
  assert.deepStrictEqual(
    Object.keys(schema.properties).sort(),
    [...DECISION_ALLOWED_PROPERTIES].sort()
  );
  assert.deepStrictEqual(
    [...schema.required].sort(),
    DECISION_ALLOWED_PROPERTIES.filter(
      (property) =>
        !["restrictions", "policyReferences", "expiresAt"].includes(
          property
        )
    ).sort()
  );

  assert.deepStrictEqual(
    validateAuthorizationDecision(grantedDecision(), request),
    []
  );

  const failClosed = createFailClosedDecision(
    request,
    "GDA integration is unavailable."
  );
  assert.deepStrictEqual(
    validateAuthorizationDecision(failClosed, request),
    []
  );

  assert.deepStrictEqual(
    validateAuthorizationDecision(requiresHumanDecision(), request),
    []
  );

  const grantedWithoutExpiry = grantedDecision();
  delete grantedWithoutExpiry.expiresAt;
  expectError(grantedWithoutExpiry, request, 'requires "expiresAt"');

  const deniedWithAllowed = createFailClosedDecision(request, "Unavailable.");
  deniedWithAllowed.allowed = true;
  expectError(
    deniedWithAllowed,
    request,
    "a non-granted decision requires allowed = false"
  );

  expectError(
    grantedDecision({ decidedBy: "fail-closed-default" }),
    request,
    "fail-closed-default requires"
  );

  expectError(
    requiresHumanDecision({ requiresHumanApproval: false }),
    request,
    "requiresHumanApproval = true"
  );

  expectError(
    grantedDecision({ unexpected: true }),
    request,
    'unknown property "unexpected" is not allowed'
  );

  expectError(
    grantedDecision({ requestId: "different-request" }),
    request,
    "requestId must match"
  );

  expectError(
    grantedDecision({ grantedPermissions: ["administer"] }),
    request,
    'granted permission "administer" was not requested'
  );

  expectError(
    grantedDecision({
      grantedPermissions: ["read"],
      deniedPermissions: ["read"]
    }),
    request,
    'permission "read" cannot be both granted and denied'
  );

  expectError(
    grantedDecision({ expiresAt: "2000-01-01T00:00:00.000Z" }),
    request,
    "requires a future expiresAt"
  );

  const failClosedScenarios = [];
  for (const operation of [
    "read",
    "write",
    "administer",
    "destructive"
  ]) {
    for (const requestedPermissions of [
      [],
      ["read"],
      ["cross-repository-write"]
    ]) {
      failClosedScenarios.push(
        validRequest({ operation, requestedPermissions })
      );
    }
  }
  for (const scenario of failClosedScenarios) {
    const decision = createFailClosedDecision(
      scenario,
      "No valid authorization decision is available."
    );
    assert.strictEqual(decision.decision, "denied");
    assert.strictEqual(decision.allowed, false);
    assert.strictEqual(decision.decidedBy, "fail-closed-default");
    assert.deepStrictEqual(
      validateAuthorizationDecision(decision, scenario),
      []
    );
  }

  return 13;
}

module.exports = runAuthorizationDecisionContracts;
