"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const {
  WORKSPACE_ALLOWED_PROPERTIES,
  validateWorkspaceConfig
} = require("../../tools/validate-config.cjs");

const PROJECT_ROOT = path.resolve(__dirname, "..", "..");

function validWorkspace(overrides = {}) {
  return {
    workspaceId: "gm-ai-workspace",
    name: "GM_AI_Workspace",
    version: "0.1.0",
    operationalWorkspaceRoot: "D:\\docs\\ai",
    governanceRepositoryRoot: "D:\\GDA",
    repositoriesDirectory: "D:\\",
    failClosed: true,
    humanApprovalRequiredFor: ["cross-repository-write"],
    ...overrides
  };
}

function expectError(config, expectedText) {
  const errors = validateWorkspaceConfig(config, "test workspace");
  assert.ok(
    errors.some((error) => error.includes(expectedText)),
    `Expected error containing "${expectedText}", received: ${errors.join(" | ")}`
  );
}

function runWorkspaceConfigContracts() {
  assert.deepStrictEqual(validateWorkspaceConfig(validWorkspace()), []);

  const missingWorkspaceId = validWorkspace();
  delete missingWorkspaceId.workspaceId;
  expectError(missingWorkspaceId, 'missing required field "workspaceId"');

  expectError(
    validWorkspace({ failClosed: "true" }),
    '"failClosed" must be a boolean'
  );
  expectError(
    validWorkspace({ humanApprovalRequiredFor: "security-change" }),
    '"humanApprovalRequiredFor" must be an array'
  );
  expectError(
    validWorkspace({ unknownProperty: true }),
    'unknown property "unknownProperty" is not allowed'
  );

  const schema = JSON.parse(
    fs.readFileSync(
      path.join(PROJECT_ROOT, "schemas", "workspace-config.schema.json"),
      "utf8"
    )
  );
  assert.strictEqual(schema.additionalProperties, false);
  assert.deepStrictEqual(
    Object.keys(schema.properties).sort(),
    [...WORKSPACE_ALLOWED_PROPERTIES].sort()
  );
  assert.deepStrictEqual(
    [...schema.required].sort(),
    [...WORKSPACE_ALLOWED_PROPERTIES].sort()
  );

  const realWorkspace = JSON.parse(
    fs.readFileSync(
      path.join(PROJECT_ROOT, "config", "workspace.json"),
      "utf8"
    )
  );
  assert.deepStrictEqual(
    validateWorkspaceConfig(realWorkspace, "config/workspace.json"),
    []
  );
}

module.exports = runWorkspaceConfigContracts;
