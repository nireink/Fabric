"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const {
  REQUEST_ALLOWED_PROPERTIES,
  validateAuthorizationRequest
} = require("../../tools/validate-authorization.cjs");

const PROJECT_ROOT = path.resolve(__dirname, "..", "..");

function validRequest(overrides = {}) {
  return {
    requestId: "request-001",
    timestamp: "2026-07-24T12:00:00.000Z",
    actorType: "ai-agent",
    actorId: "codex-session",
    agent: "future-registered-agent",
    repositoryId: "gystigo",
    operation: "write",
    targetPaths: ["src/example.js"],
    reason: "Implement an explicitly authorized change.",
    requestedPermissions: ["read", "write"],
    correlationId: "correlation-001",
    evidence: ["prompt-boundary-001"],
    ...overrides
  };
}

function expectError(value, expectedText) {
  const errors = validateAuthorizationRequest(value);
  assert.ok(
    errors.some((error) => error.includes(expectedText)),
    `Expected error containing "${expectedText}", received: ${errors.join(" | ")}`
  );
}

function runAuthorizationRequestContracts() {
  assert.deepStrictEqual(validateAuthorizationRequest(validRequest()), []);

  const schema = JSON.parse(
    fs.readFileSync(
      path.join(
        PROJECT_ROOT,
        "schemas",
        "authorization-request.schema.json"
      ),
      "utf8"
    )
  );
  assert.strictEqual(schema.additionalProperties, false);
  assert.deepStrictEqual(
    Object.keys(schema.properties).sort(),
    [...REQUEST_ALLOWED_PROPERTIES].sort()
  );
  assert.deepStrictEqual(
    [...schema.required].sort(),
    REQUEST_ALLOWED_PROPERTIES.filter(
      (property) => property !== "evidence"
    ).sort()
  );

  const missingRequestId = validRequest();
  delete missingRequestId.requestId;
  expectError(missingRequestId, 'missing required field "requestId"');

  expectError(
    validRequest({ requestId: "   " }),
    '"requestId" must be a non-empty string'
  );
  expectError(
    validRequest({ actorType: "robot" }),
    '"actorType" must be one of'
  );
  expectError(
    validRequest({ operation: "execute" }),
    '"operation" must be one of'
  );
  expectError(
    validRequest({ targetPaths: "src/example.js" }),
    '"targetPaths" must be an array'
  );
  expectError(
    validRequest({ unexpected: true }),
    'unknown property "unexpected" is not allowed'
  );
  expectError(
    validRequest({ timestamp: "2026-02-30T12:00:00Z" }),
    '"timestamp" must be a valid ISO date-time string'
  );

  return 8;
}

module.exports = runAuthorizationRequestContracts;
