"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const {
  REPOSITORY_ALLOWED_PROPERTIES,
  validateRepositoryCollection,
  validateRepositoryConfig
} = require("../../tools/validate-config.cjs");

const PROJECT_ROOT = path.resolve(__dirname, "..", "..");
const AUTHORITATIVE_RESTRICTED_PATHS = path.resolve(
  PROJECT_ROOT,
  "..",
  "docs",
  "ai",
  "config",
  "restricted-paths.json"
);

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function validRepository(overrides = {}) {
  return {
    repositoryId: "example",
    name: "Example",
    root: "D:\\example",
    status: "pending-gda-integration",
    governanceProvider: "GDA",
    allowedAgents: [],
    readOnlyAgents: ["Claude"],
    restrictedPaths: [],
    requireHumanApprovalFor: ["cross-repository-write"],
    auditRequired: true,
    ...overrides
  };
}

function expectError(config, expectedText) {
  const errors = validateRepositoryConfig(config, "test repository");
  assert.ok(
    errors.some((error) => error.includes(expectedText)),
    `Expected error containing "${expectedText}", received: ${errors.join(" | ")}`
  );
}

function expectRestrictedPathsMismatch(candidate, authoritative) {
  assert.throws(
    () => assert.deepStrictEqual(candidate, authoritative),
    assert.AssertionError
  );
}

function runRepositoryConfigContracts() {
  assert.deepStrictEqual(validateRepositoryConfig(validRepository()), []);

  const missingRepositoryId = validRepository();
  delete missingRepositoryId.repositoryId;
  expectError(missingRepositoryId, 'missing required field "repositoryId"');

  expectError(
    validRepository({ repositoryId: "   " }),
    '"repositoryId" must be a non-empty string'
  );
  expectError(
    validRepository({ auditRequired: "true" }),
    '"auditRequired" must be a boolean'
  );
  expectError(
    validRepository({ restrictedPaths: "src/" }),
    '"restrictedPaths" must be an array'
  );
  expectError(
    validRepository({ unknownProperty: true }),
    'unknown property "unknownProperty" is not allowed'
  );

  const duplicateErrors = validateRepositoryCollection([
    { label: "first.json", config: validRepository() },
    { label: "second.json", config: validRepository() }
  ]);
  assert.ok(
    duplicateErrors.some((error) =>
      error.includes('duplicate repositoryId "example"')
    ),
    `Expected duplicate repositoryId error, received: ${duplicateErrors.join(" | ")}`
  );

  const schema = readJson(
    path.join(PROJECT_ROOT, "schemas", "repository-config.schema.json")
  );
  assert.strictEqual(schema.additionalProperties, false);
  assert.deepStrictEqual(
    Object.keys(schema.properties).sort(),
    [...REPOSITORY_ALLOWED_PROPERTIES].sort()
  );
  assert.deepStrictEqual(
    [...schema.required].sort(),
    [...REPOSITORY_ALLOWED_PROPERTIES].sort()
  );
  assert.match(
    schema.properties.allowedAgents.description,
    /does not grant write permission/i
  );

  const admittedCodex = validRepository({
    allowedAgents: ["Codex"],
    readOnlyAgents: []
  });
  assert.deepStrictEqual(validateRepositoryConfig(admittedCodex), []);
  assert.strictEqual(
    Object.prototype.hasOwnProperty.call(admittedCodex, "writePermission"),
    false
  );

  const repositoryDirectory = path.join(
    PROJECT_ROOT,
    "config",
    "repositories"
  );
  const repositoryEntries = fs
    .readdirSync(repositoryDirectory)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => ({
      label: `config/repositories/${fileName}`,
      config: readJson(path.join(repositoryDirectory, fileName))
    }));
  assert.deepStrictEqual(validateRepositoryCollection(repositoryEntries), []);

  const gystigo = readJson(
    path.join(repositoryDirectory, "gystigo.json")
  );
  const authoritative = readJson(AUTHORITATIVE_RESTRICTED_PATHS);
  assert.strictEqual(authoritative.restrictedPaths.length, 22);
  assert.deepStrictEqual(
    validateRepositoryConfig(gystigo, "config/repositories/gystigo.json"),
    []
  );
  assert.deepStrictEqual(
    gystigo.restrictedPaths,
    authoritative.restrictedPaths
  );

  expectRestrictedPathsMismatch(
    authoritative.restrictedPaths.slice(0, -1),
    authoritative.restrictedPaths
  );
  expectRestrictedPathsMismatch(
    [...authoritative.restrictedPaths, "unexpected/path/"],
    authoritative.restrictedPaths
  );

  const altered = [...authoritative.restrictedPaths];
  altered[1] = "platform_os/studio/runtime/bootstrap/";
  expectRestrictedPathsMismatch(altered, authoritative.restrictedPaths);

  const reordered = [...authoritative.restrictedPaths];
  [reordered[0], reordered[1]] = [reordered[1], reordered[0]];
  expectRestrictedPathsMismatch(reordered, authoritative.restrictedPaths);
}

module.exports = runRepositoryConfigContracts;
