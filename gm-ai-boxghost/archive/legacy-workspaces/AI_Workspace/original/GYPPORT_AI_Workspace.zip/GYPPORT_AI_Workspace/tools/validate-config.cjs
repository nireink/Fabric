"use strict";

const fs = require("node:fs");
const path = require("node:path");

const WORKSPACE_ALLOWED_PROPERTIES = [
  "workspaceId",
  "name",
  "version",
  "operationalWorkspaceRoot",
  "governanceRepositoryRoot",
  "repositoriesDirectory",
  "failClosed",
  "humanApprovalRequiredFor"
];

const WORKSPACE_REQUIRED_STRINGS = [
  "workspaceId",
  "name",
  "version",
  "operationalWorkspaceRoot",
  "governanceRepositoryRoot",
  "repositoriesDirectory"
];

const REPOSITORY_ALLOWED_PROPERTIES = [
  "repositoryId",
  "name",
  "root",
  "status",
  "governanceProvider",
  "allowedAgents",
  "readOnlyAgents",
  "restrictedPaths",
  "requireHumanApprovalFor",
  "auditRequired"
];

const REPOSITORY_REQUIRED_STRINGS = [
  "repositoryId",
  "name",
  "root",
  "status",
  "governanceProvider"
];

const REPOSITORY_REQUIRED_ARRAYS = [
  "allowedAgents",
  "readOnlyAgents",
  "restrictedPaths",
  "requireHumanApprovalFor"
];

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function validateRequiredString(config, field, label, errors) {
  if (!Object.prototype.hasOwnProperty.call(config, field)) {
    errors.push(`${label}: missing required field "${field}".`);
    return;
  }

  if (typeof config[field] !== "string" || config[field].trim() === "") {
    errors.push(`${label}: field "${field}" must be a non-empty string.`);
  }
}

function validateRequiredArray(config, field, label, errors) {
  if (!Object.prototype.hasOwnProperty.call(config, field)) {
    errors.push(`${label}: missing required field "${field}".`);
    return;
  }

  if (!Array.isArray(config[field])) {
    errors.push(`${label}: field "${field}" must be an array.`);
    return;
  }

  for (let index = 0; index < config[field].length; index += 1) {
    const value = config[field][index];
    if (typeof value !== "string" || value.trim() === "") {
      errors.push(
        `${label}: field "${field}" item at index ${index} must be a non-empty string.`
      );
    }
  }
}

function validateAdditionalProperties(
  config,
  allowedProperties,
  label,
  errors
) {
  const allowed = new Set(allowedProperties);
  for (const field of Object.keys(config)) {
    if (!allowed.has(field)) {
      errors.push(`${label}: unknown property "${field}" is not allowed.`);
    }
  }
}

function validateWorkspaceConfig(config, label = "workspace config") {
  const errors = [];

  if (!isObject(config)) {
    return [`${label}: configuration must be a JSON object.`];
  }

  validateAdditionalProperties(
    config,
    WORKSPACE_ALLOWED_PROPERTIES,
    label,
    errors
  );

  for (const field of WORKSPACE_REQUIRED_STRINGS) {
    validateRequiredString(config, field, label, errors);
  }

  if (!Object.prototype.hasOwnProperty.call(config, "failClosed")) {
    errors.push(`${label}: missing required field "failClosed".`);
  } else if (typeof config.failClosed !== "boolean") {
    errors.push(`${label}: field "failClosed" must be a boolean.`);
  }

  validateRequiredArray(
    config,
    "humanApprovalRequiredFor",
    label,
    errors
  );

  return errors;
}

function validateRepositoryConfig(config, label = "repository config") {
  const errors = [];

  if (!isObject(config)) {
    return [`${label}: configuration must be a JSON object.`];
  }

  validateAdditionalProperties(
    config,
    REPOSITORY_ALLOWED_PROPERTIES,
    label,
    errors
  );

  for (const field of REPOSITORY_REQUIRED_STRINGS) {
    validateRequiredString(config, field, label, errors);
  }

  for (const field of REPOSITORY_REQUIRED_ARRAYS) {
    validateRequiredArray(config, field, label, errors);
  }

  if (!Object.prototype.hasOwnProperty.call(config, "auditRequired")) {
    errors.push(`${label}: missing required field "auditRequired".`);
  } else if (typeof config.auditRequired !== "boolean") {
    errors.push(`${label}: field "auditRequired" must be a boolean.`);
  }

  return errors;
}

function validateRepositoryCollection(entries) {
  const errors = [];
  const seenIds = new Map();

  for (const entry of entries) {
    const label = entry.label || "repository config";
    errors.push(...validateRepositoryConfig(entry.config, label));

    if (
      isObject(entry.config) &&
      typeof entry.config.repositoryId === "string" &&
      entry.config.repositoryId.trim() !== ""
    ) {
      const repositoryId = entry.config.repositoryId.trim();
      if (seenIds.has(repositoryId)) {
        errors.push(
          `${label}: duplicate repositoryId "${repositoryId}" (already declared in ${seenIds.get(repositoryId)}).`
        );
      } else {
        seenIds.set(repositoryId, label);
      }
    }
  }

  return errors;
}

function readJson(filePath) {
  try {
    return { config: JSON.parse(fs.readFileSync(filePath, "utf8")) };
  } catch (error) {
    return {
      error: `${filePath}: could not read valid JSON (${error.message}).`
    };
  }
}

function main() {
  const projectRoot = path.resolve(__dirname, "..");
  const workspacePath = path.join(projectRoot, "config", "workspace.json");
  const repositoriesPath = path.join(
    projectRoot,
    "config",
    "repositories"
  );
  const errors = [];

  const workspaceResult = readJson(workspacePath);
  if (workspaceResult.error) {
    errors.push(workspaceResult.error);
  } else {
    errors.push(
      ...validateWorkspaceConfig(workspaceResult.config, "config/workspace.json")
    );
  }

  let repositoryFiles = [];
  try {
    repositoryFiles = fs
      .readdirSync(repositoriesPath, { withFileTypes: true })
      .filter((entry) => entry.isFile() && entry.name.endsWith(".json"))
      .map((entry) => entry.name)
      .sort();
  } catch (error) {
    errors.push(
      `${repositoriesPath}: could not list repository configuration files (${error.message}).`
    );
  }

  if (repositoryFiles.length === 0) {
    errors.push("config/repositories: no repository configuration files found.");
  }

  const repositoryEntries = [];
  for (const fileName of repositoryFiles) {
    const filePath = path.join(repositoriesPath, fileName);
    const result = readJson(filePath);
    if (result.error) {
      errors.push(result.error);
    } else {
      repositoryEntries.push({
        label: `config/repositories/${fileName}`,
        config: result.config
      });
    }
  }

  errors.push(...validateRepositoryCollection(repositoryEntries));

  if (errors.length > 0) {
    console.error("Configuration validation failed:");
    for (const error of errors) {
      console.error(`- ${error}`);
    }
    process.exitCode = 1;
    return;
  }

  console.log(
    `Configuration validation passed: 1 workspace and ${repositoryEntries.length} repositories.`
  );
}

if (require.main === module) {
  main();
}

module.exports = {
  REPOSITORY_ALLOWED_PROPERTIES,
  WORKSPACE_ALLOWED_PROPERTIES,
  validateRepositoryCollection,
  validateRepositoryConfig,
  validateWorkspaceConfig
};
