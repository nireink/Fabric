"use strict";

const fs = require("node:fs");
const path = require("node:path");

function main() {
  const schemasPath = path.resolve(__dirname, "..", "schemas");
  const errors = [];
  let schemaFiles = [];

  try {
    schemaFiles = fs
      .readdirSync(schemasPath, { withFileTypes: true })
      .filter(
        (entry) => entry.isFile() && entry.name.endsWith(".schema.json")
      )
      .map((entry) => entry.name)
      .sort();
  } catch (error) {
    errors.push(
      `${schemasPath}: could not list schema files (${error.message}).`
    );
  }

  if (schemaFiles.length === 0) {
    errors.push("schemas: no *.schema.json files found.");
  }

  for (const fileName of schemaFiles) {
    const filePath = path.join(schemasPath, fileName);
    let schema;

    try {
      schema = JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch (error) {
      errors.push(`${fileName}: invalid JSON (${error.message}).`);
      continue;
    }

    if (
      typeof schema.$schema !== "string" ||
      schema.$schema.trim() === ""
    ) {
      errors.push(`${fileName}: missing non-empty "$schema" declaration.`);
    }

    if (typeof schema.type !== "string" || schema.type.trim() === "") {
      errors.push(`${fileName}: missing non-empty "type" declaration.`);
    }

    if (schema.additionalProperties !== false) {
      errors.push(
        `${fileName}: "additionalProperties" must be explicitly false.`
      );
    }

    if (
      schema.properties === null ||
      typeof schema.properties !== "object" ||
      Array.isArray(schema.properties)
    ) {
      errors.push(`${fileName}: "properties" must be an object.`);
    }

    if (!Array.isArray(schema.required)) {
      errors.push(`${fileName}: "required" must be an array.`);
    } else if (
      schema.properties !== null &&
      typeof schema.properties === "object" &&
      !Array.isArray(schema.properties)
    ) {
      for (const requiredProperty of schema.required) {
        if (
          !Object.prototype.hasOwnProperty.call(
            schema.properties,
            requiredProperty
          )
        ) {
          errors.push(
            `${fileName}: required property "${requiredProperty}" is not declared in "properties".`
          );
        }
      }
    }
  }

  if (errors.length > 0) {
    console.error("Schema validation failed:");
    for (const error of errors) {
      console.error(`- ${error}`);
    }
    process.exitCode = 1;
    return;
  }

  console.log(`Schema validation passed: ${schemaFiles.length} schemas.`);
}

main();
