#!/usr/bin/env node
'use strict';

/**
 * gyp-ai local panel — no external dependencies.
 *
 * A local-only viewer/decision panel over docs/ai/. It is NOT part of
 * Platform OS, does not deploy anywhere, and is not reachable outside this
 * machine (binds to 127.0.0.1 only). It exists to answer one question
 * honestly: "can I get a screen to approve/reject AI Workspace items this
 * week without opening a new Platform OS track or coupling Studio to a
 * folder outside its own repository." See ADR-0005 in
 * docs/ai/decisions/pending/ for why it lives here and not inside Gystigo.
 *
 * Run: node tools/gyp-ai/server.cjs [port]
 * Then open http://127.0.0.1:<port> in a browser, on this machine only.
 *
 * Every write action requires the human to type their name and check a
 * confirmation box in the browser — the server does not assume approval,
 * it only records what a person typed. AI_COLLABORATION.md rule 5 ("no AI
 * expands a boundary without approval") applies to this tool too: nothing
 * here lets an agent approve its own or another agent's work.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const REQUIRED_AI_ROOT_DIRECTORIES = ['config', 'findings', 'reviews', 'decisions'];

function resolveAiRoot() {
  const configured = process.env.GYPPORT_AI_ROOT;
  if (!configured || configured.trim() === '') {
    throw new Error(
      'GYPPORT_AI_ROOT is required and must point to the operational AI workspace.'
    );
  }
  if (!path.isAbsolute(configured)) {
    throw new Error('GYPPORT_AI_ROOT must be an absolute path: ' + configured);
  }

  const resolved = path.resolve(configured);
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) {
    throw new Error('GYPPORT_AI_ROOT does not exist or is not a directory: ' + resolved);
  }

  const missing = REQUIRED_AI_ROOT_DIRECTORIES.filter((name) => {
    const candidate = path.join(resolved, name);
    return !fs.existsSync(candidate) || !fs.statSync(candidate).isDirectory();
  });
  if (missing.length > 0) {
    throw new Error(
      'GYPPORT_AI_ROOT is missing required directories: ' + missing.join(', ')
    );
  }

  return resolved;
}

const AI_ROOT = resolveAiRoot();
const REGISTRY_PATH = path.join(AI_ROOT, 'findings', 'registry.json');
const REVIEWS_PENDING = path.join(AI_ROOT, 'reviews', 'pending');
const REVIEWS_ACCEPTED = path.join(AI_ROOT, 'reviews', 'accepted');
const REVIEWS_REJECTED = path.join(AI_ROOT, 'reviews', 'rejected');
const DECISIONS_APPROVED = path.join(AI_ROOT, 'decisions', 'approved');
const PUBLIC_DIR = path.join(__dirname, 'public');

const PORT = Number(process.argv[2]) || 4287;

function listFilesRecursive(dir, baseDir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  entries.forEach((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...listFilesRecursive(full, baseDir));
    } else if (entry.name !== 'README.md') {
      out.push(path.relative(baseDir, full).split(path.sep).join('/'));
    }
  });
  return out;
}

// Refuses any relative path that escapes REVIEWS_PENDING, including via
// "..", symlink tricks are out of scope for a single-user local tool.
function resolveSafeReviewPath(relPath) {
  const resolved = path.resolve(REVIEWS_PENDING, relPath);
  if (!resolved.startsWith(REVIEWS_PENDING + path.sep) && resolved !== REVIEWS_PENDING) {
    return null;
  }
  if (!fs.existsSync(resolved)) return null;
  return resolved;
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function sendFile(res, filePath, contentType) {
  if (!fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end('Not found');
    return;
  }
  const body = fs.readFileSync(filePath);
  res.writeHead(200, { 'Content-Type': contentType });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 2_000_000) req.destroy(); // 2MB guard, local tool only
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function nowStamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  try {
    if (req.method === 'GET' && pathname === '/') {
      sendFile(res, path.join(PUBLIC_DIR, 'index.html'), 'text/html; charset=utf-8');
      return;
    }

    if (req.method === 'GET' && pathname === '/api/findings') {
      const registry = fs.existsSync(REGISTRY_PATH)
        ? JSON.parse(fs.readFileSync(REGISTRY_PATH, 'utf8'))
        : { findings: [] };
      sendJson(res, 200, registry.findings || []);
      return;
    }

    if (req.method === 'GET' && pathname === '/api/reviews/pending') {
      sendJson(res, 200, listFilesRecursive(REVIEWS_PENDING, REVIEWS_PENDING));
      return;
    }

    if (req.method === 'GET' && pathname === '/api/reviews/history') {
      sendJson(res, 200, {
        accepted: listFilesRecursive(REVIEWS_ACCEPTED, REVIEWS_ACCEPTED),
        rejected: listFilesRecursive(REVIEWS_REJECTED, REVIEWS_REJECTED),
      });
      return;
    }

    if (req.method === 'GET' && pathname === '/api/review-content') {
      const rel = parsed.query.path || '';
      const resolved = resolveSafeReviewPath(rel);
      if (!resolved) {
        sendJson(res, 404, { error: 'Not found or outside reviews/pending' });
        return;
      }
      sendJson(res, 200, { path: rel, content: fs.readFileSync(resolved, 'utf8') });
      return;
    }

    if (req.method === 'POST' && pathname === '/api/decide') {
      const raw = await readBody(req);
      let payload;
      try {
        payload = JSON.parse(raw);
      } catch (e) {
        sendJson(res, 400, { error: 'Invalid JSON body' });
        return;
      }

      const { reviewPath, action, approverName, confirmed, note } = payload;
      if (!reviewPath || !action || !approverName || confirmed !== true) {
        sendJson(res, 400, {
          error:
            'reviewPath, action, approverName are required and confirmed must be true. ' +
            'This tool does not infer approval — a person must type their name and check the box.',
        });
        return;
      }
      if (action !== 'approve' && action !== 'reject') {
        sendJson(res, 400, { error: 'action must be "approve" or "reject"' });
        return;
      }

      const resolved = resolveSafeReviewPath(reviewPath);
      if (!resolved) {
        sendJson(res, 404, { error: 'Review not found in reviews/pending' });
        return;
      }

      const destDir = action === 'approve' ? REVIEWS_ACCEPTED : REVIEWS_REJECTED;
      const destPath = path.join(destDir, reviewPath);
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      fs.renameSync(resolved, destPath);

      if (action === 'approve') {
        const decisionId = 'DECISION-' + nowStamp();
        const decisionRecord = {
          decisionId,
          reviewPath: 'reviews/accepted/' + reviewPath,
          preparedBy: 'gyp-ai-local-panel',
          approvedBy: approverName,
          approvalMethod: 'explicit_human_confirmation_in_local_panel',
          note: note || null,
          decidedAt: new Date().toISOString(),
        };
        fs.writeFileSync(
          path.join(DECISIONS_APPROVED, decisionId + '.json'),
          JSON.stringify(decisionRecord, null, 2) + '\n',
          'utf8'
        );
        sendJson(res, 200, { status: 'approved', decisionId, movedTo: destPath });
        return;
      }

      sendJson(res, 200, { status: 'rejected', movedTo: destPath });
      return;
    }

    res.writeHead(404);
    res.end('Not found');
  } catch (err) {
    sendJson(res, 500, { error: String(err && err.message ? err.message : err) });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  process.stdout.write(
    'gyp-ai local panel running at http://127.0.0.1:' +
      PORT +
      ' (127.0.0.1 only — not reachable from other machines)\n' +
      'AI_ROOT: ' +
      AI_ROOT +
      '\n'
  );
});
