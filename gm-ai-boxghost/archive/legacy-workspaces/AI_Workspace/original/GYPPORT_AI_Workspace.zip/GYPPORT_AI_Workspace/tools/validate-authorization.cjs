"use strict";

const REQUEST_ALLOWED_PROPERTIES = [
  "requestId",
  "timestamp",
  "actorType",
  "actorId",
  "agent",
  "repositoryId",
  "operation",
  "targetPaths",
  "reason",
  "requestedPermissions",
  "correlationId",
  "evidence"
];

const DECISION_ALLOWED_PROPERTIES = [
  "requestId",
  "decisionId",
  "decision",
  "allowed",
  "requiresHumanApproval",
  "grantedPermissions",
  "deniedPermissions",
  "reason",
  "decidedBy",
  "decidedAt",
  "auditReference",
  "restrictions",
  "policyReferences",
  "expiresAt"
];

const ACTOR_TYPES = ["human", "ai-agent", "service"];
const OPERATIONS = ["read", "write", "administer", "destructive"];
const DECISIONS = ["granted", "denied", "requires-human-approval"];
const DECIDERS = ["GDA", "Human", "fail-closed-default"];

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isNonEmptyString(value) {
  return typeof value === "string" && value.trim() !== "";
}

function validateAdditionalProperties(value, allowedProperties, label, errors) {
  const allowed = new Set(allowedProperties);
  for (const property of Object.keys(value)) {
    if (!allowed.has(property)) {
      errors.push(`${label}: unknown property "${property}" is not allowed.`);
    }
  }
}

function validateString(value, property, label, errors) {
  if (!Object.prototype.hasOwnProperty.call(value, property)) {
    errors.push(`${label}: missing required field "${property}".`);
  } else if (!isNonEmptyString(value[property])) {
    errors.push(`${label}: field "${property}" must be a non-empty string.`);
  }
}

function validateBoolean(value, property, label, errors) {
  if (!Object.prototype.hasOwnProperty.call(value, property)) {
    errors.push(`${label}: missing required field "${property}".`);
  } else if (typeof value[property] !== "boolean") {
    errors.push(`${label}: field "${property}" must be a boolean.`);
  }
}

function validateEnum(value, property, allowedValues, label, errors) {
  if (!Object.prototype.hasOwnProperty.call(value, property)) {
    errors.push(`${label}: missing required field "${property}".`);
  } else if (!allowedValues.includes(value[property])) {
    errors.push(
      `${label}: field "${property}" must be one of: ${allowedValues.join(", ")}.`
    );
  }
}

function validateStringArray(
  value,
  property,
  label,
  errors,
  options = {}
) {
  const present = Object.prototype.hasOwnProperty.call(value, property);
  if (!present) {
    if (options.required !== false) {
      errors.push(`${label}: missing required field "${property}".`);
    }
    return;
  }

  if (!Array.isArray(value[property])) {
    errors.push(`${label}: field "${property}" must be an array.`);
    return;
  }

  const seen = new Set();
  for (let index = 0; index < value[property].length; index += 1) {
    const item = value[property][index];
    if (!isNonEmptyString(item)) {
      errors.push(
        `${label}: field "${property}" item at index ${index} must be a non-empty string.`
      );
      continue;
    }
    if (options.unique === true && seen.has(item)) {
      errors.push(
        `${label}: field "${property}" must contain unique items; duplicate "${item}".`
      );
    }
    seen.add(item);
  }
}

function isValidIsoDateTime(value) {
  if (typeof value !== "string") {
    return false;
  }

  const match = value.match(
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})$/
  );
  if (!match) {
    return false;
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  const second = Number(match[6]);

  if (
    month < 1 ||
    month > 12 ||
    day < 1 ||
    day > new Date(Date.UTC(year, month, 0)).getUTCDate() ||
    hour > 23 ||
    minute > 59 ||
    second > 59
  ) {
    return false;
  }

  if (match[7] !== "Z") {
    const [offsetHour, offsetMinute] = match[7]
      .slice(1)
      .split(":")
      .map(Number);
    if (offsetHour > 23 || offsetMinute > 59) {
      return false;
    }
  }

  return !Number.isNaN(Date.parse(value));
}

function validateDateTime(
  value,
  property,
  label,
  errors,
  options = {}
) {
  const present = Object.prototype.hasOwnProperty.call(value, property);
  if (!present) {
    if (options.required !== false) {
      errors.push(`${label}: missing required field "${property}".`);
    }
    return;
  }

  if (!isValidIsoDateTime(value[property])) {
    errors.push(
      `${label}: field "${property}" must be a valid ISO date-time string.`
    );
  }
}

function validateAuthorizationRequest(value) {
  const label = "AuthorizationRequest";
  const errors = [];

  if (!isObject(value)) {
    return [`${label}: value must be a JSON object.`];
  }

  validateAdditionalProperties(
    value,
    REQUEST_ALLOWED_PROPERTIES,
    label,
    errors
  );

  for (const property of [
    "requestId",
    "actorId",
    "agent",
    "repositoryId",
    "reason",
    "correlationId"
  ]) {
    validateString(value, property, label, errors);
  }

  validateDateTime(value, "timestamp", label, errors);
  validateEnum(value, "actorType", ACTOR_TYPES, label, errors);
  validateEnum(value, "operation", OPERATIONS, label, errors);
  validateStringArray(value, "targetPaths", label, errors);
  validateStringArray(value, "requestedPermissions", label, errors, {
    unique: true
  });
  validateStringArray(value, "evidence", label, errors, {
    required: false,
    unique: true
  });

  return errors;
}

function validateAuthorizationDecision(value, request, now = new Date()) {
  const label = "AuthorizationDecision";
  const errors = [];

  if (!isObject(value)) {
    return [`${label}: value must be a JSON object.`];
  }

  validateAdditionalProperties(
    value,
    DECISION_ALLOWED_PROPERTIES,
    label,
    errors
  );

  for (const property of [
    "requestId",
    "decisionId",
    "reason",
    "auditReference"
  ]) {
    validateString(value, property, label, errors);
  }

  validateEnum(value, "decision", DECISIONS, label, errors);
  validateEnum(value, "decidedBy", DECIDERS, label, errors);
  validateBoolean(value, "allowed", label, errors);
  validateBoolean(value, "requiresHumanApproval", label, errors);
  validateDateTime(value, "decidedAt", label, errors);
  validateDateTime(value, "expiresAt", label, errors, { required: false });

  for (const property of ["grantedPermissions", "deniedPermissions"]) {
    validateStringArray(value, property, label, errors, { unique: true });
  }
  for (const property of ["restrictions", "policyReferences"]) {
    validateStringArray(value, property, label, errors, {
      required: false,
      unique: true
    });
  }

  if (value.decision === "granted" && value.allowed !== true) {
    errors.push(`${label}: decision "granted" requires allowed = true.`);
  }
  if (
    DECISIONS.includes(value.decision) &&
    value.decision !== "granted" &&
    value.allowed !== false
  ) {
    errors.push(`${label}: a non-granted decision requires allowed = false.`);
  }
  if (
    value.allowed === true &&
    !Object.prototype.hasOwnProperty.call(value, "expiresAt")
  ) {
    errors.push(`${label}: allowed = true requires "expiresAt".`);
  }
  if (
    value.decidedBy === "fail-closed-default" &&
    (value.decision !== "denied" || value.allowed !== false)
  ) {
    errors.push(
      `${label}: fail-closed-default requires decision "denied" and allowed = false.`
    );
  }
  if (
    value.decision === "requires-human-approval" &&
    (value.allowed !== false || value.requiresHumanApproval !== true)
  ) {
    errors.push(
      `${label}: requires-human-approval requires allowed = false and requiresHumanApproval = true.`
    );
  }

  if (
    Array.isArray(value.grantedPermissions) &&
    Array.isArray(value.deniedPermissions)
  ) {
    const denied = new Set(value.deniedPermissions);
    for (const permission of value.grantedPermissions) {
      if (denied.has(permission)) {
        errors.push(
          `${label}: permission "${permission}" cannot be both granted and denied.`
        );
      }
    }
  }

  if (isObject(request)) {
    if (
      isNonEmptyString(value.requestId) &&
      isNonEmptyString(request.requestId) &&
      value.requestId !== request.requestId
    ) {
      errors.push(
        `${label}: requestId must match the accompanying AuthorizationRequest.`
      );
    }

    if (
      Array.isArray(value.grantedPermissions) &&
      Array.isArray(request.requestedPermissions)
    ) {
      const requested = new Set(request.requestedPermissions);
      for (const permission of value.grantedPermissions) {
        if (!requested.has(permission)) {
          errors.push(
            `${label}: granted permission "${permission}" was not requested.`
          );
        }
      }
    }
  }

  if (
    value.decision === "granted" &&
    isValidIsoDateTime(value.expiresAt)
  ) {
    const nowTime = now instanceof Date ? now.getTime() : Date.parse(now);
    const effectiveNow = Number.isNaN(nowTime) ? Date.now() : nowTime;
    if (Date.parse(value.expiresAt) <= effectiveNow) {
      errors.push(`${label}: a granted decision requires a future expiresAt.`);
    }
  }

  return errors;
}

function createFailClosedDecision(request, reason) {
  const safeRequest = isObject(request) ? request : {};
  const requestId = isNonEmptyString(safeRequest.requestId)
    ? safeRequest.requestId
    : "unidentified-request";
  const requestedPermissions = Array.isArray(
    safeRequest.requestedPermissions
  )
    ? [
        ...new Set(
          safeRequest.requestedPermissions.filter(isNonEmptyString)
        )
      ]
    : [];
  const requiresHumanApproval =
    safeRequest.operation === "destructive" ||
    requestedPermissions.includes("cross-repository-write");

  return {
    requestId,
    decisionId: `fail-closed-${requestId}`,
    decision: "denied",
    allowed: false,
    requiresHumanApproval,
    grantedPermissions: [],
    deniedPermissions: requestedPermissions,
    reason: isNonEmptyString(reason)
      ? reason
      : "No valid authorization decision is available.",
    decidedBy: "fail-closed-default",
    decidedAt: new Date().toISOString(),
    auditReference: `fail-closed:${requestId}`
  };
}

function main() {
  const request = {
    requestId: "validation-request",
    timestamp: new Date().toISOString(),
    actorType: "service",
    actorId: "local-validator",
    agent: "local-validator",
    repositoryId: "gm-ai-workspace",
    operation: "read",
    targetPaths: ["schemas/"],
    reason: "Validate representative authorization contracts.",
    requestedPermissions: ["read"],
    correlationId: "validation-correlation"
  };
  const decision = createFailClosedDecision(
    request,
    "No functional GDA integration is available."
  );
  const errors = [
    ...validateAuthorizationRequest(request),
    ...validateAuthorizationDecision(decision, request)
  ];

  if (
    decision.decision !== "denied" ||
    decision.allowed !== false ||
    decision.decidedBy !== "fail-closed-default"
  ) {
    errors.push(
      "createFailClosedDecision violated the mandatory fail-closed invariant."
    );
  }

  if (errors.length > 0) {
    console.error("Authorization validation failed:");
    for (const error of errors) {
      console.error(`- ${error}`);
    }
    process.exitCode = 1;
    return;
  }

  console.log(
    "Authorization validation passed: representative request and fail-closed decision."
  );
}

if (require.main === module) {
  main();
}

module.exports = {
  DECISION_ALLOWED_PROPERTIES,
  REQUEST_ALLOWED_PROPERTIES,
  createFailClosedDecision,
  validateAuthorizationDecision,
  validateAuthorizationRequest
};
