#!/usr/bin/env node
'use strict';

/**
 * gyp-ai CLI — no external dependencies.
 *
 * Mechanizes two decisions that ADR-0005 identified as unsafe to leave to
 * informal judgment each time:
 *
 *   1. check-boundary <promptFile>
 *      Does a Codex-facing prompt's AUTHORIZED SURFACE touch a path this
 *      project considers sensitive? If yes, Claude must review the prompt
 *      before it is pasted into Codex (MANDATORY_LEVEL_2_AUDIT).
 *
 *   2. new-finding / list-findings / close-finding
 *      A finding can only move to RESOLVED if a real review file is given,
 *      that review contains an explicit, unambiguous positive verdict, and
 *      that review text actually references the finding's id. Whoever
 *      implemented the fix (Codex) cannot close a finding just by saying
 *      "done" — closure requires the auditor's (Claude's) verdict artifact.
 *
 * Known, deliberate limitations are documented at the bottom of this file
 * and in docs/ai/decisions/pending/ADR-0005... — read them before trusting
 * this tool for anything it does not explicitly claim to do.
 */

const fs = require('fs');
const path = require('path');

const REQUIRED_AI_ROOT_DIRECTORIES = ['config', 'findings', 'reviews', 'decisions'];

function resolveAiRoot() {
  const configured = process.env.GYPPORT_AI_ROOT;
  if (!configured || configured.trim() === '') {
    throw new Error(
      'GYPPORT_AI_ROOT is required and must point to the operational AI workspace.'
    );
  }
  if (!path.isAbsolute(configured)) {
    throw new Error('GYPPORT_AI_ROOT must be an absolute path: ' + configured);
  }

  const resolved = path.resolve(configured);
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) {
    throw new Error('GYPPORT_AI_ROOT does not exist or is not a directory: ' + resolved);
  }

  const missing = REQUIRED_AI_ROOT_DIRECTORIES.filter((name) => {
    const candidate = path.join(resolved, name);
    return !fs.existsSync(candidate) || !fs.statSync(candidate).isDirectory();
  });
  if (missing.length > 0) {
    throw new Error(
      'GYPPORT_AI_ROOT is missing required directories: ' + missing.join(', ')
    );
  }

  return resolved;
}

const AI_ROOT = resolveAiRoot();
const REGISTRY_PATH = path.join(AI_ROOT, 'findings', 'registry.json');
const RESTRICTED_PATHS_FILE = path.join(AI_ROOT, 'config', 'restricted-paths.json');

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function readJson(filePath) {
  const raw = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(raw);
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token.startsWith('--')) {
      const key = token.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) {
        out[key] = true;
      } else {
        if (out[key] === undefined) {
          out[key] = next;
        } else if (Array.isArray(out[key])) {
          out[key].push(next);
        } else {
          out[key] = [out[key], next];
        }
        i += 1;
      }
    } else {
      out._.push(token);
    }
  }
  return out;
}

function fail(message) {
  process.stderr.write('ERROR: ' + message + '\n');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// check-boundary
// ---------------------------------------------------------------------------

// Section titles that mark the start of the block of files Codex is actually
// authorized to touch. Extend this list as new prompt templates appear —
// keep it specific; a marker that is too generic will swallow unrelated
// sections and reintroduce the false-positive bug this tool was built to
// avoid (a restricted path named only to PROTECT it must never trigger).
const SURFACE_START_MARKERS = [
  'SUPERFICIE AUTORIZADA',
  'SUPERFICIE MÍNIMA DE CAMBIO',
  'SUPERFICIE MINIMA DE CAMBIO',
  'AUTHORIZED SURFACE',
  'ARCHIVOS AUTORIZADOS',
];

// Phrases that indicate the prompt still leaves an architectural decision
// open for Codex to resolve mid-implementation. Soft signal only — reported
// as a warning, never blocks by itself.
const OPEN_DECISION_MARKERS = [
  /decide si/i,
  /determina si (?:debe|corresponde|conviene)/i,
  /eval[uú]a si conviene/i,
  /decide entre/i,
  /seg[uú]n convenga/i,
  /decidir[aá]? (?:la|el|una) estrategia/i,
];

function isHeadingLine(line) {
  const trimmed = line.trim();
  if (trimmed.length < 4) return false;
  // A heading line in these documents is written in caps, with no lowercase
  // letters (Latin, including accented). Bullet markers / numbering allowed.
  const hasLowercase = /[a-záéíóúñü]/.test(trimmed);
  const hasLetters = /[A-ZÁÉÍÓÚÑÜ]/.test(trimmed);
  return hasLetters && !hasLowercase;
}

function extractSurfaceBlock(text) {
  const lines = text.split(/\r?\n/);
  let startIndex = -1;
  for (let i = 0; i < lines.length; i += 1) {
    const upper = lines[i].toUpperCase();
    if (SURFACE_START_MARKERS.some((marker) => upper.includes(marker))) {
      startIndex = i + 1;
      break;
    }
  }
  if (startIndex === -1) return null;

  const collected = [];
  for (let i = startIndex; i < lines.length; i += 1) {
    if (i > startIndex && isHeadingLine(lines[i])) break;
    collected.push(lines[i]);
  }
  return collected.join('\n');
}

function checkBoundary(promptFile) {
  if (!fs.existsSync(promptFile)) fail('Prompt file not found: ' + promptFile);
  const text = fs.readFileSync(promptFile, 'utf8');

  let restrictedPaths = [];
  if (fs.existsSync(RESTRICTED_PATHS_FILE)) {
    restrictedPaths = readJson(RESTRICTED_PATHS_FILE).restrictedPaths || [];
  }

  const surfaceBlock = extractSurfaceBlock(text);

  const result = {
    promptFile,
    verdict: null,
    matchedRestrictedPaths: [],
    openDecisionMarkersFound: [],
    surfaceBlockFound: surfaceBlock !== null,
  };

  if (surfaceBlock === null) {
    result.verdict = 'NO_AUTHORIZED_SURFACE_FOUND';
    result.note =
      'No section matching ' +
      JSON.stringify(SURFACE_START_MARKERS) +
      ' was found. This tool refuses to scan the whole document for restricted ' +
      'paths, because that previously caused a false positive on prompts that ' +
      'name a sensitive file only to protect it. Add an explicit authorized-surface ' +
      'section to the prompt, or review manually.';
    printCheckResult(result);
    return result;
  }

  restrictedPaths.forEach((restricted) => {
    if (surfaceBlock.includes(restricted)) {
      result.matchedRestrictedPaths.push(restricted);
    }
  });

  OPEN_DECISION_MARKERS.forEach((re) => {
    const match = surfaceBlock.match(re) || text.match(re);
    if (match) result.openDecisionMarkersFound.push(match[0]);
  });

  if (result.matchedRestrictedPaths.length > 0) {
    result.verdict = 'MANDATORY_LEVEL_2_AUDIT';
  } else if (result.openDecisionMarkersFound.length > 0) {
    result.verdict = 'WARNINGS_ONLY';
  } else {
    result.verdict = 'OK_FOR_LEVEL_1';
  }

  printCheckResult(result);
  return result;
}

function printCheckResult(result) {
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
}

// ---------------------------------------------------------------------------
// findings
// ---------------------------------------------------------------------------

function loadRegistry() {
  if (!fs.existsSync(REGISTRY_PATH)) {
    return { $schemaRef: '../schemas/finding.schema.json', findings: [] };
  }
  return readJson(REGISTRY_PATH);
}

function saveRegistry(registry) {
  writeJson(REGISTRY_PATH, registry);
}

function newFinding(args) {
  const id = args.id;
  const title = args.title;
  const severity = (args.severity || '').toUpperCase();
  if (!id || !/^GYP-F[0-9]{4}$/.test(id)) fail('--id must match GYP-F0000 format');
  if (!title) fail('--title is required');
  if (!['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(severity)) {
    fail('--severity must be one of LOW, MEDIUM, HIGH, CRITICAL');
  }

  const registry = loadRegistry();
  if (registry.findings.some((f) => f.id === id)) fail('Finding ' + id + ' already exists.');

  const evidenceArg = args.evidence
    ? Array.isArray(args.evidence)
      ? args.evidence
      : [args.evidence]
    : [];
  if (evidenceArg.length === 0) fail('At least one --evidence "description" is required.');

  const finding = {
    id,
    title,
    severity,
    status: 'OPEN',
    originReview: args.originReview || null,
    evidence: evidenceArg.map((description) => ({ description })),
    resolution: null,
    createdAt: new Date().toISOString(),
    closedAt: null,
    closedByReview: null,
    assignedStep: args.assignedStep || null,
  };

  registry.findings.push(finding);
  saveRegistry(registry);
  process.stdout.write('Created ' + id + ' (status OPEN).\n');
}

function listFindings(args) {
  const registry = loadRegistry();
  const statusFilter = args.status ? String(args.status).toUpperCase() : null;
  const rows = registry.findings.filter((f) => !statusFilter || f.status === statusFilter);
  if (rows.length === 0) {
    process.stdout.write('(no findings match)\n');
    return;
  }
  rows.forEach((f) => {
    process.stdout.write(
      f.id + '  [' + f.severity + ']  ' + f.status + '  ' + f.title + '\n'
    );
  });
}

// Verdict vocabulary. \b word boundaries are load-bearing: without them,
// "PASS" matches inside "passed", which is exactly the bug that let a FAIL
// review close a finding in an earlier build of this tool. Do not remove
// the \b to "fix" an unrelated matching problem — extend the vocabulary list
// instead.
const POSITIVE_VERDICT_RE =
  /\b(PASS|PASS_WITH_CONDITIONS|PASS_WITH_WARNINGS|APPROVED|APPROVED_WITH_CONDITIONS|OK_FOR_LEVEL_1|OWNERSHIP_CONFIRMED)\b/i;
const NEGATIVE_VERDICT_RE =
  /\b(FAIL|FAILED|REJECTED|BLOCKED|REQUIRES_CORRECTION|REQUIRES_REVISION|MANDATORY_LEVEL_2_AUDIT|UNSAFE_TO_CONTINUE)\b/i;

function closeFinding(args) {
  const id = args.id;
  const reviewPath = args.review;
  if (!id) fail('--id is required');
  if (!reviewPath) fail('--review <path-to-review-file> is required');
  if (!fs.existsSync(reviewPath)) fail('Review file not found: ' + reviewPath);

  const registry = loadRegistry();
  const finding = registry.findings.find((f) => f.id === id);
  if (!finding) fail('Finding ' + id + ' not found.');
  if (finding.status === 'RESOLVED') fail(id + ' is already RESOLVED.');

  const reviewText = fs.readFileSync(reviewPath, 'utf8');

  // Negative wins over positive if both somehow appear — refusing to close
  // is always the safe default.
  if (NEGATIVE_VERDICT_RE.test(reviewText)) {
    fail(
      'Review ' +
        reviewPath +
        ' contains a negative verdict token (' +
        reviewText.match(NEGATIVE_VERDICT_RE)[0] +
        '). Refusing to close ' +
        id +
        '.'
    );
  }
  if (!POSITIVE_VERDICT_RE.test(reviewText)) {
    fail(
      'Review ' +
        reviewPath +
        ' does not contain an explicit positive verdict token. Refusing to close ' +
        id +
        ' (fail-closed: ambiguous review text is not accepted).'
    );
  }
  if (!reviewText.includes(id)) {
    fail(
      'Review ' + reviewPath + ' does not mention ' + id + ' anywhere. Refusing to close.'
    );
  }

  finding.status = 'RESOLVED';
  finding.resolution = args.note || 'Closed via review verdict.';
  finding.closedAt = new Date().toISOString();
  finding.closedByReview = reviewPath;
  saveRegistry(registry);
  process.stdout.write('Closed ' + id + ' (verdict confirmed in ' + reviewPath + ').\n');
}

// ---------------------------------------------------------------------------
// check-drift
// ---------------------------------------------------------------------------

// Shallow, honest check: this does NOT understand meaning. It confirms the
// pinned constraints block text is still physically present in a later turn
// file, and flags common override phrases. A turn can still drift in ways
// this does not catch (e.g. paraphrasing the block instead of restating it
// verbatim, or contradicting it without using any flagged phrase). Treat a
// clean result as "no obvious drift", never as "drift-free".
const PINNED_BLOCK_MARKER = /PINNED CONSTRAINTS BLOCK/i;

const OVERRIDE_PHRASES = [
  /ignora (?:la|esta|esa) regla/i,
  /olvida (?:la|esta|esa) restricci[oó]n/i,
  /no aplica en este caso/i,
  /hagamos una excepci[oó]n/i,
  /por esta vez/i,
  /salta(?:mos)? el proceso/i,
  /omite (?:el|este) paso/i,
  /ignore (?:this|that) rule/i,
  /skip the process/i,
  /just this once/i,
];

const BLOCK_END_DELIMITER = /^-{3,}\s*$/;

function extractPinnedBlock(text) {
  const lines = text.split(/\r?\n/);
  const markerIndex = lines.findIndex((l) => PINNED_BLOCK_MARKER.test(l));
  if (markerIndex === -1) return { text: null, delimiterMissing: false, markerMissing: true };
  const collected = [];
  let sawEndDelimiter = false;
  for (let i = markerIndex + 1; i < lines.length; i += 1) {
    if (BLOCK_END_DELIMITER.test(lines[i])) {
      sawEndDelimiter = true;
      break;
    }
    if (i > markerIndex + 1 && isHeadingLine(lines[i])) break;
    collected.push(lines[i]);
  }
  // Without an explicit "---" end delimiter, there is no reliable boundary
  // between the pinned block and the rest of the turn's actual content —
  // the block would silently swallow (or be swallowed by) whatever follows
  // it. Refuse to guess; require the delimiter instead of comparing noise.
  if (!sawEndDelimiter) return { text: null, delimiterMissing: true };
  return { text: collected.join('\n').trim(), delimiterMissing: false };
}

function checkDrift(turnFile, referenceFile) {
  if (!fs.existsSync(turnFile)) fail('Turn file not found: ' + turnFile);
  if (!referenceFile) fail('--reference <firstTurnFile> is required');
  if (!fs.existsSync(referenceFile)) fail('Reference file not found: ' + referenceFile);

  const turnText = fs.readFileSync(turnFile, 'utf8');
  const referenceText = fs.readFileSync(referenceFile, 'utf8');

  const reference = extractPinnedBlock(referenceText);
  const turn = extractPinnedBlock(turnText);

  const result = {
    turnFile,
    referenceFile,
    referenceBlockFound: reference.text !== null,
    referenceDelimiterMissing: reference.delimiterMissing,
    turnBlockFound: turn.text !== null,
    turnDelimiterMissing: turn.delimiterMissing,
    blockMatchesVerbatim: false,
    overridePhrasesFound: [],
    verdict: null,
    note:
      'Shallow check only: confirms the pinned block text is still present ' +
      'verbatim (delimited by a line of "---") and flags known override ' +
      'phrases. Does not understand meaning. A clean result means "no ' +
      'obvious drift", not "drift-free".',
  };

  if (reference.text !== null && turn.text !== null) {
    result.blockMatchesVerbatim = reference.text === turn.text;
  }

  OVERRIDE_PHRASES.forEach((re) => {
    const match = turnText.match(re);
    if (match) result.overridePhrasesFound.push(match[0]);
  });

  if (reference.delimiterMissing || reference.text === null) {
    result.verdict = 'REFERENCE_HAS_NO_PINNED_BLOCK';
  } else if (turn.delimiterMissing || turn.text === null) {
    result.verdict = 'DRIFT_SUSPECTED_BLOCK_MISSING_OR_UNDELIMITED';
  } else if (result.overridePhrasesFound.length > 0) {
    result.verdict = 'DRIFT_SUSPECTED_OVERRIDE_PHRASE';
  } else if (!result.blockMatchesVerbatim) {
    result.verdict = 'DRIFT_SUSPECTED_BLOCK_CHANGED';
  } else {
    result.verdict = 'NO_OBVIOUS_DRIFT';
  }

  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  return result;
}

// ---------------------------------------------------------------------------
// entrypoint
// ---------------------------------------------------------------------------

function main() {
  const [, , command, ...rest] = process.argv;
  const args = parseArgs(rest);

  switch (command) {
    case 'check-boundary': {
      const promptFile = args._[0];
      if (!promptFile) fail('Usage: cli.cjs check-boundary <promptFile>');
      checkBoundary(promptFile);
      break;
    }
    case 'new-finding':
      newFinding(args);
      break;
    case 'list-findings':
      listFindings(args);
      break;
    case 'close-finding':
      closeFinding(args);
      break;
    case 'check-drift': {
      const turnFile = args._[0];
      if (!turnFile) fail('Usage: cli.cjs check-drift <turnFile> --reference <firstTurnFile>');
      checkDrift(turnFile, args.reference);
      break;
    }
    default:
      process.stdout.write(
        [
          'gyp-ai CLI',
          '',
          'Usage:',
          '  node cli.cjs check-boundary <promptFile>',
          '  node cli.cjs check-drift <turnFile> --reference <firstTurnFile>',
          '  node cli.cjs new-finding --id GYP-F0003 --title "..." --severity HIGH --evidence "..." [--evidence "..."] [--assignedStep STEP-ID]',
          '  node cli.cjs list-findings [--status OPEN|RESOLVED|DEFERRED|REJECTED]',
          '  node cli.cjs close-finding --id GYP-F0001 --review path/to/review.md [--note "..."]',
          '',
        ].join('\n')
      );
  }
}

main();
