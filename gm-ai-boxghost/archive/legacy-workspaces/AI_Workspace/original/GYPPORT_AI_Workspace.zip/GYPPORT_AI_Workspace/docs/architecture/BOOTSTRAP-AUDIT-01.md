# ARCHIVED / SUPERSEDED — NO EJECUTAR INSTRUCCIONES OBSOLETAS

Este documento antecede a GYP-ADR-0001 y conserva rutas,
nomenclatura y prompts de una arquitectura sustituida.

No ejecutar directamente los prompts o comandos aquí contenidos.

Nomenclatura sustituida:
- GM_AI_Workspace → GYPPORT_AI_Workspace
- GDA como ruta directa → Governance/GYPPORT_Governance_Architecture

Corrección técnica posterior:
- cli.cjs y server.cjs dependían de una resolución relativa frágil de AI_ROOT.
- La implementación vigente utiliza configuración explícita de GYPPORT_AI_ROOT.

El documento se conserva únicamente como evidencia histórica.

# BOOTSTRAP-AUDIT-01 — Auditoría inicial de GM_AI_Workspace

**Autor:** Claude (rol: Analista/Auditor read-only, según `GM_AI_Workspace — Contexto maestro`, sección 4).
**Fecha:** 2026-07-23.
**Alcance:** Solo lectura. No se modificó `Gystigo`, no se movió ni borró ningún artefacto existente de `docs/ai/`, no se creó código todavía.
**Responde a:** sección 16 del documento "GM_AI_Workspace — Contexto maestro de inicio" ("Siguiente paso correcto").

---

## 0. Corrección de un supuesto del documento base (evidencia antes de conclusión)

El documento maestro utilizó inicialmente una ruta simplificada bajo `D:\`. La ubicación real del workspace general de GYPPORT es:

```text
D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\
├── docs\ai\
├── Fabric\
├── GDA\
├── GM_AI_Workspace\
├── GM_Service_Management\
└── Gystigo\
```

Estas carpetas existen actualmente como componentes hermanos dentro del workspace general. La existencia de una carpeta no demuestra por sí sola que todos los componentes tengan implementación funcional completa o que todos cuenten con un repositorio Git inicializado y limpio.

La ubicación real de cada elemento relevante para este bootstrap es:

- Repositorio propietario de la solución multiagente:  
  `D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\GM_AI_Workspace`
- Workspace operativo transversal actual:  
  `D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai`
- Repositorio principal actualmente coordinado:  
  `D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\Gystigo`
- Gobernanza transversal:  
  `D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\GDA`

Esto no cambia las decisiones ya cerradas del documento maestro:

- `GM_AI_Workspace` permanece fuera de `Gystigo`.
- `GM_AI_Workspace` permanece fuera de `docs`.
- `GM_AI_Workspace` es multirrepositorio.
- `GDA` es la autoridad de gobernanza.
- `docs\ai` almacena artefactos operativos y no es el propietario arquitectónico del sistema.

También se aclara el estado del archivo `gypport-ai-workspace.zip`:

- El ZIP fue adjuntado y revisado dentro de ChatGPT como material de referencia.
- El ZIP no está almacenado actualmente dentro del repositorio local `GM_AI_Workspace`.
- Por tanto, este bootstrap no debe asumir que existe un paquete local pendiente de copiar.
- La incorporación de ideas o componentes de ese ZIP debe hacerse de forma selectiva y controlada, nunca mediante una copia completa sin adaptación.

La base reutilizable real que ya existe localmente se encuentra principalmente en:

- `docs\ai\`
- `tools\gyp-ai\`

Esos elementos deben tratarse como fuentes de referencia y activos operativos existentes. No deben moverse ni modificarse durante este bootstrap sin una decisión explícita posterior.

---


---

## 1. Inventario de archivos actuales

### 1.1 `GM_AI_Workspace/` (el repositorio nuevo)

Estado verificado al 2026-07-23:

- El repositorio Git local existe.
- El remoto configurado es:
  `https://github.com/GYPPORT/GM_AI_Workspace.git`
- La rama activa es `master`.
- Se eliminó la referencia rota hacia un upstream inexistente.
- Ya existe un commit raíz:

```text
05154d9 chore(ai-workspace): initialize GM_AI_Workspace repository
```

Contenido versionado en ese commit:

```text
.gitignore
README.md
docs/project/GM_AI_WORKSPACE_MASTER_CONTEXT.md
```

Contenido todavía no versionado al momento de esta auditoría:

```text
docs/architecture/BOOTSTRAP-AUDIT-01.md
```

Por tanto, `GM_AI_Workspace` ya no está vacío, pero todavía no contiene implementación funcional del sistema multiagente.

Estado correcto:

- Contexto maestro: documentado.
- Repositorio Git: inicializado.
- Primer commit: creado.
- Código funcional: no implementado.
- CLI propio: no implementado dentro de este repositorio.
- Integración con GDA: no implementada.
- Flujo multiagente automatizado: no implementado.


### 1.2 `docs/ai/` (el workspace operativo transversal)

Contrario a lo que el documento maestro sugiere ("puede almacenar..."), esta carpeta **ya tiene historial operativo real**, no solo la estructura vacía construida en esta sesión. Inventario real:

**Construido en sesiones previas de este proyecto (antes de esta conversación):**
- `docs/ai/handoffs/codex-to-review/AIWS-004-NATIVE-RECOVERY/` — 3 rondas (RC1, RC2, RC3) de un incidente real de recuperación nativa: scripts `.ps1`, resultados de prueba, resultados de construcción.
- `docs/ai/handoffs/codex-to-review/AIWS-003-RC-STRUCTURAL-ROOT/` — otro incidente real (staging, rehearsal, pre/post-state).
- `docs/ai/handoffs/codex-to-review/WORKSPACE-BASELINE/DIAGNOSTIC-GTEXT-01/` — diagnóstico real de un bug de scanner, con causa raíz documentada, diff de código, manifiesto de integridad (`MANIFEST.sha256`).
- `docs/ai/handoffs/codex-to-review/WORKSPACE-DEEP-SCAN/CODEX-01-PREPARATION/` — preparación de un escaneo profundo del workspace.
- `docs/ai/handoffs/codex-to-review/GYPPORT-FACTUAL-INVENTORY/` y `docs/ai/handoffs/claude-to-architect/GYPPORT-FACTUAL-INVENTORY/CLAUDE-01/` — un inventario factual completo de GYPPORT (directorios, archivos, estado Git, commits, backups, artefactos AIWS, estructura del proyecto, hechos de migración, problemas, indicadores de secretos, log de ejecución, resumen ejecutivo) — 17 archivos con evidencia cruda.
- `docs/ai/reviews/pending/CLAUDE-REVIEW-AIWS-004-NATIVE-RECOVERY-RC1.md` y `docs/ai/reviews/pending/WORKSPACE-BASELINE/DIAGNOSTIC-GTEXT-01/CLAUDE-REVIEW-...md` — revisiones de Claude ya redactadas, en estado pendiente.

**Construido en esta sesión (gobernanza y protocolo):**
- `docs/ai/schemas/finding.schema.json`, `docs/ai/schemas/codex-prompt-boundary.md`
- `docs/ai/config/restricted-paths.json`
- `docs/ai/findings/registry.json` (2 findings reales: GYP-F0001, GYP-F0002)
- `docs/ai/workspace/CURRENT_RULES.md`, `ACTIVE_BOUNDARY.md`, `NEXT_STEP.md`, `CONTEXT-BRIEF-BROWSER-SHELL-AUTH.md`
- `docs/ai/decisions/pending/ADR-0005-DRAFT-ai-workspace-debate-and-review-protocol.md` (v7, PROPOSED)
- `docs/ai/handoffs/claude-to-chatgpt/001-proposal.md` (debate AUTH-04 en curso)
- `docs/ai/decisions/approved/DECISION-2026-07-23T00-39-13-715Z.json` y `docs/ai/reviews/accepted/TEST-SYNTHETIC/test-review.md` — **2 artefactos sintéticos de prueba, todavía sin borrar** (pendiente de una autorización de borrado que Eduardo no ha completado; no son artefactos reales de trabajo).

### 1.3 `tools/gyp-ai/` (la herramienta ya construida)

- `cli.cjs` — CLI de Node sin dependencias externas: `check-boundary`, `new-finding`, `list-findings`, `close-finding`, `check-drift`.
- `server.cjs` — servidor HTTP local (solo `127.0.0.1:4287`) para el panel de aprobación: endpoints de findings, reviews pendientes/historial, y `/api/decide` para aprobar/rechazar con protección contra path traversal.
- `public/index.html` — interfaz del panel (lista de findings, lista de reviews con botones Ver/Aprobar/Rechazar, modal de confirmación con nombre + checkbox).

Esta es, en la práctica, la respuesta real a "qué contiene el ZIP" — el equivalente ya construido y parcialmente probado existe, solo que vive hoy en `tools/gyp-ai/` y `docs/ai/`, no en un paquete separado.

### 1.4 `Gystigo/docs/ai/`

No auditado en este turno (fuera del alcance de este primer bootstrap; según la sección 2 del documento maestro, se trata como documentación local/histórica de ese repo, no como el workspace transversal).

---

## 2. Clasificación: reutilizar / adaptar / descartar

El ZIP revisado en ChatGPT no está presente dentro del repositorio local. Por eso no existe un paquete local que deba copiarse o descartarse de forma completa. Sí existen ideas y componentes reutilizables que deben migrarse selectivamente, adaptándolos a la arquitectura multirrepositorio y a la relación con GDA.

| Elemento | Estado | Clasificación | Nota |
|---|---|---|---|
| `tools/gyp-ai/cli.cjs` | Funcional, probado | **Reutilizar con adaptación** | Hoy no tiene noción de "repositorio objetivo" — asume un único árbol de trabajo. Hay que parametrizar la ruta raíz y las rutas restringidas por repo (ver sección 4). |
| `tools/gyp-ai/server.cjs` + `public/index.html` | Funcional | **Reutilizar tal cual, por ahora** | No tiene dependencia de un repo específico — ya lee/escribe sobre rutas relativas al workspace operativo. |
| `docs/ai/schemas/finding.schema.json` | Estable | **Reutilizar tal cual** | Formato de finding ya validado. |
| `docs/ai/config/restricted-paths.json` | Funcional pero de un solo repo | **Adaptar** | Se convierte en la base de `config/repositories/gystigo.json` (sección 8 del documento maestro). |
| `docs/ai/decisions/pending/ADR-0005-DRAFT-*.md` | PROPOSED v7 | **Reutilizar como insumo, no migrar el archivo** | Su contenido (protocolo de debate de 2 rondas, bloque de constraints fijado, gate de auditoría de límites) es exactamente lo que el documento maestro pide en su sección 6 ("reglas iniciales de roles", "lógica de validación"). Debe quedar referenciado desde `GM_AI_Workspace/docs/decisions/`, no duplicado. |
| `docs/ai/handoffs/*` (histórico real: AIWS-003, AIWS-004, WORKSPACE-BASELINE, GYPPORT-FACTUAL-INVENTORY) | Histórico, cerrado o pendiente según carpeta | **No mover** | Es evidencia operativa real de `docs/ai` como almacenamiento — se queda donde está, per la regla del documento maestro ("no migrar inmediatamente todos los artefactos de D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai"). |
| 2 artefactos sintéticos de prueba (`TEST-SYNTHETIC`, `DECISION-2026-07-23...json`) | Basura de prueba | **Descartar** (pendiente autorización de borrado ya solicitada, rechazada dos veces por falta de contexto — ver historial de esta sesión) | No relacionado con GM_AI_Workspace; mencionado aquí solo para no perderlo de vista. |

---

## 3. Estructura mínima propuesta para el siguiente cambio de bootstrap de `GM_AI_Workspace`

Siguiendo la sección 11 del documento maestro ("núcleo mínimo", 10 puntos) y sin construir nada de la lista de "no construir todavía":

```
GM_AI_Workspace/
├── README.md                          ← ya existe; actualizar solo si hace falta
├── AGENTS.md                          ← roles: humano, ChatGPT, Claude, Codex, GDA (copiado/adaptado de sección 4 y 5 del doc maestro)
├── package.json                       ← sin dependencias externas, igual que tools/gyp-ai actual
├── config/
│   ├── workspace.json                 ← ruta del almacenamiento operativo (hoy: D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai, no D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai)
│   └── repositories/
│       └── gystigo.json               ← ÚNICO repo real configurado por ahora (adaptado de restricted-paths.json)
├── schemas/
│   └── finding.schema.json            ← copiado tal cual de docs/ai/schemas/
├── tools/
│   └── gyp-ai/
│       ├── cli.cjs                    ← adaptado para leer config/repositories/*.json en vez de una ruta fija
│       ├── server.cjs                 ← copiado tal cual
│       └── public/index.html          ← copiado tal cual
├── docs/
│   ├── architecture/
│   │   └── BOOTSTRAP-AUDIT-01.md      ← este documento, pendiente de versionar
│   └── decisions/
│       └── (referencia a ADR-0005, no copia)
└── tests/
    └── contracts/                     ← vacío por ahora; primer contrato real: "repository config válida" (sección 5)
```

Explícitamente **fuera** de este primer cambio: una interfaz gráfica nueva, integración funcional real con GDA, soporte multirrepositorio completo y la creación prematura de `src/governance/`, `src/orchestration/`, `src/repositories/`, `src/agents/` o `src/audit/`. GDA sí existe como componente hermano, pero su contrato de integración todavía no está implementado.

---

## 4. Límites exactos del primer cambio

- Repositorio afectado: **únicamente `GM_AI_Workspace`**. Cero cambios en `Gystigo`.
- Dentro de `docs/ai/` (almacenamiento operativo): **solo lectura** para este bootstrap — no se mueve, renombra ni borra nada existente. Si en el futuro se decide migrar contenido histórico hacia `GM_AI_Workspace`, es una decisión aparte, explícita, no implícita en este commit.
- `config/repositories/gystigo.json` debe ser una **adaptación**, no una copia con más permisos: mismas rutas restringidas que ya existen en `docs/ai/config/restricted-paths.json` hoy, sin agregar ni quitar ninguna sin justificarlo.
- No se crea ningún adaptador de IA todavía (`src/agents/`) — eso implica decidir cómo se autentica cada agente, que es una pregunta de GDA, no de este bootstrap.
- No se implementa todavía la integración funcional con GDA. Tampoco debe introducirse un mock que autorice siempre, porque eso debilitaría el principio fail-closed. En esta fase solo debe definirse el contrato documental o schema de autorización, sin ejecutarlo todavía como autoridad real.

---

## 5. Contratos que deben existir antes de implementar

1. **`RepositoryConfig`** — forma exacta de cada archivo en `config/repositories/*.json` (los campos que ya lista la sección 8 del documento maestro: `repositoryId`, `name`, `root`, `governanceProvider`, `restrictedPaths`, `requireHumanApprovalFor`, etc.). Debe tener su propio JSON Schema, igual que ya existe para `finding.schema.json`.
2. **`AuthorizationRequest` / `AuthorizationDecision`** — el contrato con GDA descrito en la sección 9 del documento maestro. GDA existe físicamente, pero actualmente está vacío y no tiene implementación funcional. GDA es el propietario funcional futuro y `GM_AI_Workspace` su custodio técnico provisional. Mientras no exista integración funcional con GDA, la ausencia de una decisión válida se interpreta como denegación fail-closed. No existe ni debe crearse un mock o stub allow-all.
3. **`Finding`** — ya existe y ya está probado (`docs/ai/schemas/finding.schema.json`); se reutiliza sin cambios.
4. **`Handoff`** — no existe todavía como schema formal (hoy son archivos Markdown con una convención de bloque de constraints fijado, no un JSON Schema). Antes de automatizar más allá del bootstrap, conviene formalizarlo — pero no es bloqueante para este primer commit.

---

## 6. Prompt único propuesto para Codex (primer bootstrap)

*(Este prompt todavía no se ha enviado — queda listo para que Eduardo lo revise/autorice antes de dárselo a Codex, siguiendo el protocolo ya acordado en esta sesión.)*

```
SUPERFICIE AUTORIZADA:
- Crear o modificar archivos únicamente dentro de GM_AI_Workspace/ (repositorio ya inicializado, todavía sin implementación funcional).
- No tocar Gystigo/ bajo ninguna circunstancia.
- No mover, renombrar ni borrar nada dentro de docs/ai/ (solo lectura de esa carpeta, como referencia).

OBJETIVO:
Crear el siguiente cambio de bootstrap de GM_AI_Workspace siguiendo exactamente la
estructura mínima descrita en docs/architecture/BOOTSTRAP-AUDIT-01.md, sección 3.

TAREAS:
1. Conservar README.md y crear AGENTS.md (adaptados de las secciones 4-5 del documento maestro
   "GM_AI_Workspace — Contexto maestro de inicio").
2. package.json sin dependencias externas.
3. config/workspace.json apuntando a la ruta real del almacenamiento operativo
   (D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai, documentar explícitamente que NO es D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai todavía).
4. config/repositories/gystigo.json, adaptado de docs/ai/config/restricted-paths.json
   (copiar las mismas rutas restringidas, no agregar ninguna nueva).
5. schemas/finding.schema.json — copia exacta de docs/ai/schemas/finding.schema.json.
6. tools/gyp-ai/cli.cjs, server.cjs, public/index.html — copiar desde tools/gyp-ai/
   existente y adaptar cli.cjs para leer la ruta restringida desde
   config/repositories/gystigo.json en vez de un archivo fijo.
7. tests/contracts/ con al menos una prueba: "una configuración de repositorio
   sin repositoryId debe ser rechazada".

NO HACER:
- No crear src/governance, src/orchestration, src/agents ni ningún stub de GDA real.
- No crear interfaz gráfica nueva.
- No modificar ni mover ningún archivo fuera de GM_AI_Workspace/.

EVIDENCIA A ENTREGAR:
- Lista de archivos creados.
- Resultado de las pruebas de contrato.
- Confirmación explícita de que Gystigo/ y docs/ai/ no fueron tocados
  (git status o equivalente en ambas rutas).
```

---

## 7. Checklist de auditoría posterior de Claude (después de que Codex ejecute)

- [ ] Confirmar que `git status` en `Gystigo/` no muestra cambios.
- [ ] Confirmar que `docs/ai/` no tiene archivos movidos, renombrados ni borrados (comparar inventario contra la sección 1.2 de este documento).
- [ ] Verificar que `config/repositories/gystigo.json` tiene exactamente las mismas rutas restringidas que `docs/ai/config/restricted-paths.json` (ninguna agregada ni quitada sin justificación).
- [ ] Verificar que `cli.cjs` adaptado sigue pasando las mismas pruebas que la versión original (boundary, drift, findings).
- [ ] Confirmar que no existe ningún stub o mock allow-all y que la ausencia de una decisión válida produce denegación fail-closed.
- [ ] Confirmar que la prueba de contrato de `RepositoryConfig` (tarea 7 del prompt) realmente falla cuando falta `repositoryId`.
- [ ] Reportar en `docs/ai/reviews/pending/` con el mismo formato ya usado en revisiones anteriores (ver `CLAUDE-REVIEW-AIWS-004-NATIVE-RECOVERY-RC1.md` como referencia de formato).

---

## 8. Estado factual consolidado

```text
Ruta real:
D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\GM_AI_Workspace

Repositorio Git:
INICIALIZADO

Remoto:
https://github.com/GYPPORT/GM_AI_Workspace.git

Rama:
master

Commit raíz:
05154d9 chore(ai-workspace): initialize GM_AI_Workspace repository

Implementación funcional:
NO EXISTE TODAVÍA

Integración con GDA:
NO IMPLEMENTADA

Workspace operativo:
D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\docs\ai

Documento de auditoría:
CORREGIDO Y PENDIENTE DE VERSIONAR
```

---

## 9. Resumen para Eduardo (en simple)

El ZIP fue revisado en ChatGPT, pero no forma parte del repositorio local. `GDA`, `Fabric` y `GM_Service_Management` sí existen como carpetas hermanas dentro del workspace general. `GM_AI_Workspace` ya fue inicializado y cuenta con un primer commit documental, aunque todavía no tiene implementación funcional. La base técnica reutilizable local se encuentra principalmente en `docs/ai/` y `tools/gyp-ai/`.

El siguiente paso concreto, cuando lo autorices, es un solo prompt para Codex (sección 6 de este documento) que arma la estructura mínima dentro de `GM_AI_Workspace` sin tocar `Gystigo` ni mover nada de `docs/ai/`. Después de eso, yo audito el resultado con la checklist de la sección 7.
