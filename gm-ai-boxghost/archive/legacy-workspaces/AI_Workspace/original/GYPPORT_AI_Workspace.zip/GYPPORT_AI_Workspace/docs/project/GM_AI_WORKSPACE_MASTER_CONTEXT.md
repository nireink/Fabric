# ARCHIVED / SUPERSEDED — NO EJECUTAR INSTRUCCIONES OBSOLETAS

Este documento antecede a GYP-ADR-0001 y conserva rutas,
nomenclatura y prompts de una arquitectura sustituida.

No ejecutar directamente los prompts o comandos aquí contenidos.

Nomenclatura sustituida:
- GM_AI_Workspace → GYPPORT_AI_Workspace
- GDA como ruta directa → Governance/GYPPORT_Governance_Architecture

Corrección técnica posterior:
- cli.cjs y server.cjs dependían de una resolución relativa frágil de AI_ROOT.
- La implementación vigente utiliza configuración explícita de GYPPORT_AI_ROOT.

El documento se conserva únicamente como evidencia histórica.

# GM_AI_Workspace — Contexto maestro de inicio

## 1. Propósito del proyecto

`GM_AI_Workspace` será el sistema transversal de GYPPORT® encargado de coordinar el trabajo entre múltiples agentes de inteligencia artificial y participantes humanos.

No pertenece exclusivamente a `Gystigo` ni a ningún otro repositorio individual.

Debe poder coordinar actividades sobre:

- `Gystigo`
- `GM_Service_Management`
- `GDA`
- `Fabric`
- futuros repositorios de GYPPORT®

Su función es permitir que varias IA puedan analizar, debatir, implementar, revisar y entregar resultados mediante un flujo estructurado, auditable y gobernado, con intervención humana cuando sea necesaria.

## 2. Ubicación arquitectónica

La estructura general es:

```text
D:\
├── GM_AI_Workspace\
├── GDA\
├── Gystigo\
├── GM_Service_Management\
├── Fabric\
└── docs\
    └── ai\
```

### `GM_AI_Workspace`

Es el repositorio propietario del sistema multiagente.

Aquí deben vivir:

- Código fuente.
- CLI y herramientas.
- Orquestación de agentes.
- Adaptadores para IA.
- Configuración de repositorios.
- Esquemas.
- Plantillas.
- Validadores.
- Contratos.
- Pruebas.
- Integración con GDA.
- Documentación propia del producto.
- Futuro panel o interfaz de administración.

### `GDA`

Es la autoridad de gobernanza.

Debe definir y controlar:

- Roles.
- Permisos.
- Acceso por repositorio.
- Acceso por ruta.
- Acciones permitidas.
- Acciones que requieren aprobación humana.
- Separación de funciones.
- Auditoría.
- Suspensión y revocación de accesos.
- Políticas para agentes IA, humanos, cuentas de servicio y automatizaciones.

La relación correcta es:

```text
GDA
  ↓ gobierna
GM_AI_Workspace
  ↓ coordina
Repositorios GYPPORT
```

### `D:\docs\ai\`

Es actualmente el workspace operativo transversal donde se almacenan los artefactos reales de colaboración.

Contiene:

```text
config\
decisions\
findings\
handoffs\
reviews\
schemas\
workspace\
```

Puede almacenar:

- Handoffs.
- Revisiones.
- Decisiones.
- Hallazgos.
- Prompts pendientes.
- Debates.
- Estado activo.
- Reglas operativas.
- Evidencias de ejecución.

No es el propietario arquitectónico del sistema.

La relación correcta es:

```text
GM_AI_Workspace
  ↓ administra, valida y automatiza
D:\docs\ai
```

### `Gystigo\docs\ai\`

Cuando aparezca dentro de Gystigo o de sus worktrees, debe considerarse documentación local, histórica o específica de ese repositorio.

Puede contener:

- Prompts antiguos.
- Auditorías anteriores.
- Documentación de colaboración local.
- Evidencia ligada exclusivamente a Gystigo.

No debe confundirse con el workspace transversal operativo.

## 3. Objetivo funcional

El sistema debe permitir una conversación estructurada entre dos o más agentes IA, con capacidad de intervención humana.

Ejemplo de flujo:

```text
Humano
  ↓ define objetivo y límites

ChatGPT
  ↓ analiza, organiza y propone

Claude
  ↓ audita, critica o valida

Codex
  ↓ implementa

Claude
  ↓ revisa la implementación

Humano
  ↓ aprueba, rechaza o modifica la decisión
```

El sistema no debe depender permanentemente de que Eduardo copie manualmente mensajes entre herramientas.

Los agentes deben comunicarse mediante artefactos estructurados almacenados en el workspace.

## 4. Roles iniciales

### Humano / Arquitecto / CTO

Responsabilidades:

- Define objetivos.
- Aprueba decisiones.
- Resuelve desacuerdos.
- Autoriza cambios de alto impacto.
- Controla permisos.
- Decide excepciones.
- Puede detener cualquier ejecución.

### ChatGPT

Rol inicial:

- Orquestador de razonamiento.
- Organizador del contexto.
- Facilitador de debates.
- Generador de propuestas.
- Consolidador de decisiones.
- Preparador de prompts para otros agentes.
- Traductor entre lenguaje técnico y explicación comprensible.

No debe implementar código directamente cuando el flujo haya asignado esa responsabilidad a Codex.

### Claude

Rol inicial:

- Analista.
- Auditor.
- Revisor arquitectónico.
- Crítico read-only sobre código.
- Verificador de límites, riesgos y cumplimiento.

No debe modificar código directamente salvo que exista una autorización explícita y una política futura que lo permita.

### Codex

Rol inicial:

- Implementador.
- Ejecutor de cambios autorizados.
- Constructor de pruebas.
- Generador de evidencia técnica.
- Preparador de commits o cambios revisables.

Debe trabajar únicamente dentro del alcance aprobado.

### GDA

Rol sistémico:

- Fuente de autoridad.
- Proveedor de políticas.
- Control de roles y permisos.
- Resolución de acceso.
- Auditoría y trazabilidad.

## 5. Principios fundamentales

### Separación de responsabilidades

Cada agente debe tener un rol claro. Ningún agente debe analizar, aprobar, implementar y cerrar por sí solo una modificación sensible.

### Mínimo privilegio

Cada agente solo debe poder acceder a:

- Los repositorios necesarios.
- Las rutas necesarias.
- Las acciones necesarias.
- El tiempo necesario.

### Fail-closed

Si el sistema no puede determinar que una acción está autorizada, debe bloquearla.

### Evidencia antes de conclusión

Las decisiones deben basarse en:

- Código real.
- Estado Git real.
- Pruebas.
- Documentación vigente.
- Artefactos verificables.

### Humano en control

Toda decisión crítica debe poder escalarse al humano.

### Trazabilidad

Debe quedar registro de:

- Quién pidió la acción.
- Qué agente la analizó.
- Qué agente la implementó.
- Qué archivos se tocaron.
- Qué pruebas se ejecutaron.
- Qué agente revisó.
- Quién aprobó.
- Cuál fue el resultado final.

### No mezclar producto con artefactos operativos

`GM_AI_Workspace` contiene el sistema. `D:\docs\ai` contiene las ejecuciones, conversaciones, revisiones y decisiones reales.

## 6. Estado actual del material existente

Existe un paquete inicial llamado:

```text
gypport-ai-workspace.zip
```

Contiene una base útil con:

- CLI en Node.
- Plantillas para Claude y Codex.
- Esquemas JSON.
- Validación de límites.
- Gestión de findings.
- Handoffs.
- Reviews.
- Decisiones.
- Reglas iniciales de roles.

Sin embargo, ese paquete fue construido originalmente bajo la idea de instalar el AI Workspace dentro de `Gystigo`. No debe copiarse completo sin adaptación.

### Material reutilizable

Puede reutilizarse:

- `cli.cjs`
- Templates.
- Schemas.
- Lógica de validación.
- Gestión de findings.
- Convenciones de handoff.
- Reglas de separación entre Claude y Codex.

### Material que requiere corrección

Debe corregirse:

- La raíz del sistema.
- La detección de `docs/ai`.
- Las rutas absolutas o ligadas a Gystigo.
- La configuración única de rutas restringidas.
- La escritura de artefactos dentro del mismo repositorio.
- La ausencia de integración con GDA.
- La falta de soporte multirrepositorio.
- La falta de identidad de agente y usuario.
- La falta de pruebas contractuales.

## 7. Separación entre código y almacenamiento operativo

La estructura recomendada dentro de `GM_AI_Workspace` es:

```text
GM_AI_Workspace\
├── README.md
├── AGENTS.md
├── CLAUDE.md
├── package.json
│
├── config\
│   ├── workspace.json
│   └── repositories\
│       ├── gystigo.json
│       ├── gda.json
│       ├── gm-service-management.json
│       └── fabric.json
│
├── schemas\
│   ├── architectural-review.schema.json
│   ├── codex-handoff.schema.json
│   └── finding.schema.json
│
├── templates\
│   ├── chatgpt\
│   ├── claude\
│   └── codex\
│
├── tools\
│   └── gyp-ai\
│       └── cli.cjs
│
├── src\
│   ├── governance\
│   ├── orchestration\
│   ├── repositories\
│   ├── agents\
│   ├── workspace\
│   └── audit\
│
├── docs\
│   ├── architecture\
│   ├── decisions\
│   └── guides\
│
└── tests\
    ├── contracts\
    ├── integration\
    └── fixtures\
```

El almacenamiento operativo continúa separado:

```text
D:\docs\ai\
├── config\
├── decisions\
├── findings\
├── handoffs\
├── prompts\
├── reviews\
├── debates\
└── workspace\
```

## 8. Configuración multirrepositorio

Cada repositorio debe tener su propia configuración.

Ejemplo:

```text
config\repositories\
├── gystigo.json
├── gda.json
├── gm-service-management.json
└── fabric.json
```

Cada archivo debe poder declarar:

- ID del repositorio.
- Nombre.
- Ruta local.
- Tipo de repositorio.
- Rutas permitidas.
- Rutas restringidas.
- Agentes autorizados.
- Acciones permitidas.
- Acciones que requieren aprobación.
- Política de commits.
- Política de revisión.
- Fuente de gobernanza.
- Reglas de auditoría.

Ejemplo conceptual:

```json
{
  "repositoryId": "gystigo",
  "name": "Gystigo",
  "root": "D:\\Gystigo",
  "governanceProvider": "GDA",
  "restrictedPaths": [
    "platform_os/studio/engine/kernel/",
    "platform_os/studio/runtime/bootstrap/"
  ],
  "requireHumanApprovalFor": [
    "architecture-change",
    "security-change",
    "database-migration",
    "permission-change"
  ]
}
```

## 9. Integración futura con GDA

La integración no debe comenzar con un sistema complejo.

Primero puede definirse un contrato simple entre ambos sistemas.

`GM_AI_Workspace` consulta a GDA:

```text
¿Puede este actor ejecutar esta acción
sobre este repositorio y esta ruta?
```

GDA responde conceptualmente:

```json
{
  "allowed": true,
  "requiresHumanApproval": false,
  "policyId": "GDA-POLICY-001",
  "reason": "Agent authorized for read-only architecture review"
}
```

Contrato inicial recomendado:

```text
AuthorizationRequest
AuthorizationDecision
ActorIdentity
ResourceScope
ActionType
ApprovalRequirement
AuditRecord
```

La integración real puede empezar con archivos JSON o un adaptador local antes de crear servicios distribuidos.

## 10. Flujo operativo inicial

### Fase de análisis

1. El humano define el objetivo.
2. ChatGPT crea una propuesta estructurada.
3. Claude revisa la propuesta.
4. ChatGPT consolida.
5. El humano decide si el alcance está aprobado.

### Fase de implementación

1. Se genera un prompt limitado para Codex.
2. Se valida el boundary.
3. GDA autoriza el acceso.
4. Codex implementa.
5. Codex genera evidencia.
6. Claude revisa.
7. El humano aprueba o rechaza.

### Fase de cierre

1. Se registra la decisión.
2. Se actualizan findings.
3. Se registra el resultado.
4. Se archivan los artefactos.
5. Se define el siguiente paso.

## 11. Primer alcance recomendado

No construir todavía:

- Una interfaz gráfica completa.
- Un sistema distribuido.
- Un servidor central complejo.
- Comunicación en tiempo real entre todas las IA.
- Automatización total.
- Integración profunda con todos los repositorios.
- Un motor de workflows genérico.

Construir primero un núcleo mínimo:

1. Repositorio base.
2. Configuración del workspace.
3. Registro de repositorios.
4. CLI funcional.
5. Lectura y escritura controlada en `D:\docs\ai`.
6. Validación de rutas.
7. Identidad básica de agente.
8. Contrato básico con GDA.
9. Registro de auditoría.
10. Pruebas contractuales.

## 12. Primer objetivo técnico

El primer objetivo de `GM_AI_Workspace` debe ser:

Ejecutar un flujo completo y auditable entre ChatGPT, Claude, Codex y un humano sobre un repositorio objetivo, usando `D:\docs\ai` como almacenamiento operativo y consultando una política inicial de GDA antes de permitir acciones.

El primer flujo exitoso debería demostrar:

```text
Propuesta
→ crítica
→ aprobación humana
→ prompt para Codex
→ validación de límites
→ autorización GDA
→ implementación
→ evidencia
→ revisión Claude
→ cierre humano
```

## 13. Reglas para el desarrollo

- No modificar `Gystigo` durante el bootstrap inicial.
- No migrar inmediatamente todos los artefactos de `D:\docs\ai`.
- No eliminar documentación histórica.
- No asumir que las rutas de Gystigo aplican a todos los repositorios.
- No permitir que una IA se otorgue permisos a sí misma.
- No almacenar contraseñas, tokens o secretos en texto plano.
- No ejecutar cambios sin registrar actor, alcance y decisión.
- No iniciar una interfaz gráfica antes de cerrar el núcleo operativo.
- No convertir el proyecto en una plataforma excesivamente compleja desde el primer paso.

## 14. Decisiones ya cerradas

Estas decisiones no deben reabrirse:

1. El nombre es `GM_AI_Workspace`.
2. Debe estar fuera de `Gystigo`.
3. Debe estar fuera de `docs`.
4. Debe estar al mismo nivel que GDA, Gystigo, Fabric y los demás repositorios.
5. Debe ser multirrepositorio.
6. Debe coordinar múltiples IA y humanos.
7. GDA es la autoridad de gobernanza.
8. `D:\docs\ai` es almacenamiento operativo, no propietario del sistema.
9. `Gystigo\docs\ai` es documentación local o histórica.
10. El paquete ZIP existente es una base reutilizable, pero debe adaptarse.
11. Claude inicia como auditor read-only.
12. Codex inicia como implementador.
13. ChatGPT inicia como orquestador.
14. El humano mantiene la autoridad final.

## 15. Estado actual

```text
Repositorio GM_AI_Workspace:
CREADO

Arquitectura general:
DEFINIDA

Separación con Gystigo:
CERRADA

Relación con GDA:
DEFINIDA CONCEPTUALMENTE

Workspace operativo D:\docs\ai:
EXISTENTE

Paquete inicial:
REVISADO

Migración del paquete:
NO INICIADA

Bootstrap técnico:
PENDIENTE

Integración real con GDA:
PENDIENTE

Pruebas contractuales:
PENDIENTES

Primer flujo multiagente completo:
PENDIENTE
```

## 16. Siguiente paso correcto

El siguiente paso no es comenzar todavía con la interfaz ni copiar todo el ZIP.

El siguiente paso es:

Auditar el contenido real actual de `D:\GM_AI_Workspace`, comparar su estructura con el paquete `gypport-ai-workspace.zip` y preparar un plan de bootstrap mínimo que reutilice únicamente los componentes válidos, sin modificar Gystigo ni alterar los artefactos existentes de `D:\docs\ai`.

Resultado esperado:

- Inventario de archivos actuales.
- Clasificación reutilizar / adaptar / descartar.
- Estructura mínima propuesta.
- Límites exactos del primer cambio.
- Contratos que deben existir antes de implementar.
- Prompt único para Codex.
- Auditoría posterior de Claude.

---

## Nota de esta sesión (2026-07-23)

Este documento es el **contexto maestro original** (la propuesta/spec, tal como fue redactada). La auditoría real solicitada en la sección 16 —con la corrección de que el ZIP y los repos GDA/Fabric/GM_Service_Management todavía no existen— vive en un documento separado: `../architecture/BOOTSTRAP-AUDIT-01.md`. Ese archivo no reemplaza a este; lo complementa con evidencia verificada.
