# ADR-0001 — Authorization Contract Custody

- **Repository:** GYPPORT_AI_Workspace (alias: AIWS)
- **Status:** SUPERSEDED — *cadena de supersesión corregida el 2026-07-25, ver "Nota de corrección de cadena" abajo*
- **Fecha:** 2026-07-24
- **Superseded date:** 2026-07-24
- **Superseded by (original, ahora obsoleto):** decisión arquitectónica de consolidar GDA y AI Workspace dentro de `Gystigo/docs`
- **Propietario funcional futuro:** GDA (hoy: `GYPPORT_Governance_Architecture`, Governance/)
- **Custodio técnico provisional:** GYPPORT_AI_Workspace (antes referido como `GM_AI_Workspace`)

## ⚠️ Nota de corrección de cadena (2026-07-25)

La razón de supersesión original de este documento —*"consolidar GDA y AI Workspace dentro de `Gystigo/docs`"*— **ya no es la arquitectura vigente**. Esa decisión de consolidación fue a su vez reemplazada al día siguiente por `ADR-0001-gypport-ecosystem-structure.md` (v1.1, repositorio `GYPPORT_Governance_Architecture`, aprobado por Eduardo Luis Burgasi Pullaguari el 2026-07-25), que restablece **repositorios separados** para GDA (`GYPPORT_Governance_Architecture`), EAS (`GYPPORT_Engineering_Authority`) y AI Workspace (`GYPPORT_AI_Workspace`) — es decir, lo contrario de la consolidación que supuestamente reemplazó a este documento.

**Autoridad vigente hoy:** `GYPPORT_Governance_Architecture/decisions/adr/ADR-0001-gypport-ecosystem-structure.md` (v1.1). Cualquier lectura de este documento debe partir de ahí, no de la nota de supersesión original de más abajo.

**Estado real de las condiciones de migración a GDA (ver sección original más abajo), verificado el 2026-07-25:**

| Condición | Estado |
|---|---|
| 1. GDA tiene repositorio Git inicializado | ✅ Cumplida — `GYPPORT_Governance_Architecture` existe y está aprobado |
| 2. GDA tiene definición canónica de políticas y autorización | ❌ No cumplida — ninguno de los documentos aprobados de GDA define `AuthorizationRequest`/`AuthorizationDecision` ni un motor de políticas |
| 3. Existe una ADR específica de migración | ❌ No cumplida |
| 4. Compatibilidad de contratos verificada | ❌ No cumplida |
| 5. Consumidores actualizados sin romper fail-closed | ❌ No cumplida |

**Conclusión de esta corrección:** la condición 1 ya se cumple (algo que no era cierto cuando se escribió la nota de supersesión original), pero las condiciones 2–5 siguen sin cumplirse — en particular, `EAS` (`GYPPORT_Engineering_Authority`), que sería quien implemente el motor de políticas real, todavía no tiene ni repositorio creado. **Por tanto, la disposición técnica original de este documento (custodia provisional en AI Workspace, fail-closed por defecto) parece seguir siendo el estado operativo correcto hoy** — pero por una razón distinta a la que dice la nota de supersesión (no porque todo se haya consolidado en `Gystigo/docs`, sino porque la migración a GDA/EAS todavía no cumple sus propias condiciones).

**Esta es una decisión arquitectónica que le corresponde confirmar a Eduardo, no a este documento ni a ningún agente IA:** ¿se reactiva este ADR como `ACTIVE` (dado que su lógica de custodia provisional sigue vigente), o se mantiene formalmente `SUPERSEDED` con esta nota de corrección como el registro de por qué el contenido técnico sigue aplicando en la práctica? Ambas opciones son defendibles; lo que no puede quedar es la nota original sin corregir, porque orienta mal a cualquiera que lo lea.

---

## Nota de sustitución (original, 2026-07-24 — contexto histórico, ver corrección arriba)

Esta ADR queda sustituida porque la arquitectura vigente consolida gobernanza, contexto, memoria operativa y AI Workspace dentro del repositorio canónico Gystigo.

Motivos:

- Evitar fuentes de verdad duplicadas.
- Mantener gobernanza y memoria operativa junto al repositorio canónico.
- Permitir lectura por Codex, Claude y otros agentes al clonar Gystigo.
- Preservar los contratos y el código de este repositorio únicamente como referencia histórica.

Como consecuencia:

- GDA ya no será tratado por esta ADR como propietario funcional futuro independiente.
- `GM_AI_Workspace` deja de ser custodio técnico provisional.
- Los contratos de autorización aquí definidos no deben considerarse canónicos.
- Cualquier reutilización requiere una nueva ADR dentro de Gystigo.

El contenido original se conserva a continuación como evidencia de la decisión histórica.

## Contexto

`GM_AI_Workspace` necesita contratos estructurales para representar solicitudes y decisiones de autorización antes de que GDA disponga de integración funcional. GDA existe físicamente, pero todavía no contiene una autoridad de políticas disponible para este flujo.

## Decisión

`GM_AI_Workspace` custodiará provisionalmente los schemas y la validación local de `AuthorizationRequest` y `AuthorizationDecision`. GDA conservará la propiedad funcional futura de estos contratos y será la única fuente de decisiones de gobernanza cuando la integración exista.

Ante ausencia de GDA funcional, ausencia de decisión o decisión inválida, el resultado obligatorio es fail-closed: `decision = denied` y `allowed = false`.

## Razón

La custodia provisional permite estabilizar formatos y contratos verificables sin inventar una autoridad temporal, debilitar el mínimo privilegio ni bloquear el avance estructural del workspace.

## Límites

- No se evalúan políticas.
- No se conceden permisos.
- No se implementa comunicación con GDA.
- No existe mock o stub allow-all.
- No se persisten ni consumen decisiones.
- No se ejecutan operaciones sobre repositorios.
- `GM_AI_Workspace` no actúa como autoridad de gobernanza.

## Condiciones de migración a GDA

La custodia solo podrá migrarse cuando:

1. GDA tenga un repositorio Git inicializado.
2. GDA tenga una definición canónica de políticas y autorización.
3. Exista una ADR específica de migración.
4. La compatibilidad de contratos haya sido verificada.
5. Los consumidores hayan sido actualizados sin romper el comportamiento fail-closed.

## Consecuencias

- Los consumidores pueden validar estructuras localmente, pero no inferir autorización.
- Una decisión `granted` solo es estructuralmente válida bajo las reglas del contrato; este STEP no tiene capacidad para producirla desde políticas.
- `createFailClosedDecision` solo puede generar denegaciones.
- La futura migración a GDA deberá conservar compatibilidad o versionar explícitamente los contratos.
