# Arquitectura sustituida

- **Fecha de sustitución:** 2026-07-24
- **Estado del repositorio:** ARCHIVED / SUPERSEDED
- **Autoridad vigente:** `Gystigo/docs`

## Arquitectura anterior

La arquitectura anterior trataba:

- `GM_AI_Workspace` como repositorio transversal independiente.
- GDA como componente transversal independiente.
- `docs\ai` como almacenamiento operativo externo.
- Los contratos de autorización de este repositorio como contratos bajo custodia técnica provisional de `GM_AI_Workspace`.

## Arquitectura vigente

La arquitectura vigente establece:

- Gystigo es la raíz canónica de producto, ingeniería y documentación.
- GDA es una arquitectura documental dentro de `Gystigo/docs`.
- AI Workspace vive dentro de `Gystigo/docs/ai/workspace`.
- `Gystigo/docs` contiene gobernanza, arquitectura, contexto y memoria operativa versionada.
- `GM_AI_Workspace` es referencia histórica y técnica; no es fuente canónica.

## Motivo de la sustitución

La consolidación evita fuentes de verdad duplicadas, mantiene la gobernanza junto al repositorio canónico y permite que Codex, Claude y otros agentes accedan al contexto vigente al clonar Gystigo.

## Contenido que permanece útil

Aunque ya no sea autoritativo, este repositorio conserva material potencialmente reutilizable:

- Schemas estructurales.
- Validadores sin dependencias externas.
- Pruebas contractuales.
- Comportamiento fail-closed.
- Evidencia e historial Git.

## Contenido que deja de ser autoritativo

Ya no son decisiones vigentes:

- La ubicación independiente de GDA.
- La custodia de contratos por `GM_AI_Workspace`.
- La independencia arquitectónica de `GM_AI_Workspace`.
- La relación entre este repositorio y el `docs\ai` externo.

## Regla de no continuación

No implementar nuevas capacidades, contratos, integraciones, validadores o STEP funcionales en este repositorio. Solo se permiten tareas explícitas de archivo, corrección histórica o migración autorizada.

## Condiciones para reutilizar contenido dentro de Gystigo

Toda reutilización exige:

1. Inventario exacto del material candidato.
2. Clasificación entre reutilizar, adaptar o descartar.
3. Nueva ADR dentro de Gystigo.
4. Adaptación a las rutas y autoridades canónicas vigentes.
5. Pruebas proporcionales al contrato migrado.
6. Auditoría de límites, gobernanza y comportamiento fail-closed.
7. Commit aislado y revisable.

No se permite copiar automáticamente archivos o decisiones desde `GM_AI_Workspace`.

## Fuente canónica futura

La arquitectura canónica está prevista en:

- `Gystigo/docs/governance`
- `Gystigo/docs/ai/workspace`
- `Gystigo/docs/architecture`
