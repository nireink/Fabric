# ARCHIVED / SUPERSEDED — Restricción superior

- Ningún agente puede implementar nuevas capacidades en este repositorio.
- Claude solo puede auditar o consultar su contenido.
- Codex no debe modificar este repositorio salvo mediante un prompt explícito de archivo, corrección histórica o migración autorizada.
- ChatGPT no debe generar nuevos STEP funcionales con destino `GM_AI_Workspace`.
- Toda nueva gobernanza o AI Workspace debe dirigirse a la arquitectura canónica dentro de `Gystigo/docs`.
- La información de este repositorio tiene prioridad histórica, no autoridad vigente, y no es fuente canónica.
- No implementar nuevas capacidades ni copiar automáticamente contenido hacia la arquitectura vigente.

Los roles y principios que siguen se conservan sin reescritura como contexto histórico sustituido.

---

# Agentes y gobernanza inicial

Este repositorio opera bajo mínimo privilegio y separación de responsabilidades. Ningún rol puede ampliar su propio alcance ni otorgarse permisos.

## Roles

### Humano / Arquitecto / CTO

- Mantiene la autoridad final.
- Define objetivos, límites y excepciones.
- Aprueba acciones críticas, cambios de permisos y operaciones de alto impacto.
- Puede detener cualquier ejecución.

### ChatGPT

- Orquesta el razonamiento y consolida el contexto.
- Prepara propuestas, decisiones y prompts limitados.
- Facilita la comunicación entre participantes.
- No sustituye la aprobación humana ni asume permisos de implementación.

### Claude

- Analiza, audita y revisa.
- Opera en modo read-only por defecto.
- Debe basar sus conclusiones en evidencia verificable.
- Solo puede modificar contenido con autorización humana expresa y una política válida.

### Codex

- Implementa cambios únicamente dentro del alcance expresamente autorizado.
- Construye pruebas y genera evidencia técnica.
- No dispone de permiso global de escritura.
- Debe detenerse si el alcance, la autorización o el estado inicial no coinciden.

### GDA

- Será la fuente de políticas, permisos y decisiones de autorización.
- Proveerá reglas de acceso, aprobación, auditoría, suspensión y revocación.
- La carpeta GDA existe físicamente en `D:\NZXTG7\GYPPORT\GYPPORT ERP\GYPPORT\GDA`.
- La integración funcional con GDA todavía no está implementada.
- La existencia física de GDA no equivale a una autorización funcional disponible.
- Mientras la integración funcional esté pendiente, toda autorización no demostrada se rechaza.

## Custodia provisional de contratos de autorización

- El propietario funcional futuro de `AuthorizationRequest` y `AuthorizationDecision` es GDA.
- `GM_AI_Workspace` es únicamente el custodio técnico provisional de su estructura y validación local.
- Esta custodia no permite evaluar políticas, conceder permisos ni actuar como autoridad de gobernanza.
- La ausencia de integración con GDA o de una decisión válida siempre produce denegación fail-closed.
- No se permite ningún mock, stub o valor por defecto que conceda acceso.

## Significado de `allowedAgents`

- `allowedAgents` identifica agentes reconocidos o admitidos para participar en el contexto de un repositorio.
- La presencia de un agente en `allowedAgents` no concede por sí misma permiso de escritura.
- Toda escritura requiere un alcance explícitamente autorizado y, cuando corresponda, aprobación humana.
- Codex no recibe permiso global de escritura por aparecer en `allowedAgents`.

## Principios obligatorios

- **Mínimo privilegio:** cada actor recibe solo el acceso necesario para el objetivo autorizado.
- **Separación de responsabilidades:** análisis, aprobación, implementación y cierre sensible no recaen en un único actor.
- **Fail-closed:** ante ausencia, error o ambigüedad de autorización, la acción se bloquea.
- **Evidencia antes de conclusión:** las decisiones requieren estado real, archivos reales, pruebas y registros verificables.
- **Trazabilidad:** deben registrarse actor, alcance, archivos afectados, validaciones, revisiones, aprobaciones y resultado.
- **Sin autoasignación de permisos:** ningún humano automatizado, agente o herramienta puede ampliar su propia autoridad.
- **Límites entre repositorios:** no se modifican repositorios externos sin autorización humana expresa y específica.
- **Autoridad humana:** los cambios de permisos, gobernanza, seguridad, arquitectura y las operaciones destructivas requieren aprobación humana.
